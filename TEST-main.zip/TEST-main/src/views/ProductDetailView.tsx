import React, { useState } from 'react';
import {
  ShieldCheck,
  Leaf,
  HeartHandshake,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Info,
  ChevronDown,
  ChevronUp,
  ShoppingBag,
  ExternalLink,
  Droplets,
  Calendar,
  Share2
} from 'lucide-react';
import { VEDERA_CORE_PRODUCT, FAQS_DATA } from '../data/vederaContent';

interface ProductDetailViewProps {
  onAddToCart: () => void;
  onOpenConsultation: () => void;
  onSelectTab: (tab: string) => void;
}

export const ProductDetailView: React.FC<ProductDetailViewProps> = ({
  onAddToCart,
  onOpenConsultation,
  onSelectTab,
}) => {
  const [activeTab, setActiveTab] = useState<'inci' | 'patchTest' | 'routine' | 'faq'>('inci');
  const [selectedIngredient, setSelectedIngredient] = useState<number | null>(0);
  const [copiedLink, setCopiedLink] = useState(false);

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-16">
      {/* Breadcrumbs */}
      <nav className="flex items-center gap-2 text-xs text-[#68776B]">
        <button onClick={() => onSelectTab('home')} className="hover:text-[#1F3D2B] cursor-pointer">
          Trang chủ
        </button>
        <span aria-hidden="true">/</span>
        <button onClick={() => onSelectTab('product')} className="hover:text-[#1F3D2B] cursor-pointer">
          Sản phẩm
        </button>
        <span aria-hidden="true">/</span>
        <span className="text-[#1F3D2B] font-medium truncate">Vedera Vitamin C Serum 30ml</span>
      </nav>

      {/* Main PDP Grid (Contiguous Purchase Module + Visuals) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14">
        {/* Left Column: Visual Showcase */}
        <div className="lg:col-span-6 space-y-4">
          <div className="rounded-3xl overflow-hidden bg-[#F4EFEA] border border-[#E8E4DF] relative">
            <img
              src="/src/assets/images/product_serum_30ml_1790145833338.jpg"
              alt="Vedera Vitamin C Serum 30ml"
              referrerPolicy="no-referrer"
              className="w-full aspect-square object-cover"
            />
            <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-xs px-3 py-1 rounded-full text-xs font-medium text-[#1F3D2B] border border-white/60">
              Chai thủy tinh hổ phách 30ml chống tia UV
            </div>
          </div>

          {/* Secondary Thumbnail gallery preview */}
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-xl overflow-hidden border-2 border-[#1F3D2B] bg-[#F4EFEA]">
              <img
                src="/src/assets/images/product_serum_30ml_1790145833338.jpg"
                alt="Product front"
                referrerPolicy="no-referrer"
                className="w-full h-20 sm:h-24 object-cover"
              />
            </div>
            <div className="rounded-xl overflow-hidden border border-[#E8E4DF] bg-[#F4EFEA]">
              <img
                src="/src/assets/images/botanical_texture_leaves_1790145845639.jpg"
                alt="Botanical extracts"
                referrerPolicy="no-referrer"
                className="w-full h-20 sm:h-24 object-cover"
              />
            </div>
            <div className="rounded-xl overflow-hidden border border-[#E8E4DF] bg-[#F4EFEA]">
              <img
                src="/src/assets/images/skincare_routine_vietnamese_1790145859103.jpg"
                alt="Usage application"
                referrerPolicy="no-referrer"
                className="w-full h-20 sm:h-24 object-cover"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Contiguous Purchase Module */}
        <div className="lg:col-span-6 space-y-6">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase tracking-wider text-[#87A98D] font-medium">
                Tinh chất sáng da thuần chay
              </span>
              <button
                onClick={handleShare}
                className="text-xs text-[#68776B] hover:text-[#1F3D2B] flex items-center gap-1 cursor-pointer"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>{copiedLink ? 'Đã sao chép link' : 'Chia sẻ'}</span>
              </button>
            </div>

            <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1F3D2B] leading-tight">
              {VEDERA_CORE_PRODUCT.name}
            </h1>

            <p className="text-sm text-[#68776B]">
              {VEDERA_CORE_PRODUCT.subtitle}
            </p>
          </div>

          {/* Pricing & Value Box */}
          <div className="p-4 bg-white rounded-2xl border border-[#E8E4DF] space-y-2">
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-bold text-[#1F3D2B] tabular-nums font-mono">
                {VEDERA_CORE_PRODUCT.price.toLocaleString('vi-VN')}₫
              </span>
              <span className="text-sm text-[#87A98D] line-through tabular-nums font-mono">
                {VEDERA_CORE_PRODUCT.originalPrice?.toLocaleString('vi-VN')}₫
              </span>
              <span className="text-xs text-[#2C4A34] bg-[#EDF3EE] px-2 py-0.5 rounded font-medium">
                Tiết kiệm 11% đợt mở bán
              </span>
            </div>
            <div className="text-xs text-[#526155] flex items-center gap-4">
              <span>Dung tích: <strong>30ml (khoảng 60-75 lần dùng)</strong></span>
              <span aria-hidden="true">·</span>
              <span>Hạn mở nắp: <strong>PAO 6M</strong></span>
            </div>
          </div>

          <p className="text-sm text-[#4A574E] leading-relaxed">
            {VEDERA_CORE_PRODUCT.summary}
          </p>

          {/* 5 Highlights Bullet Points */}
          <div className="space-y-2 pt-1">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-[#1F3D2B]">
              Đặc điểm nổi bật:
            </h3>
            <ul className="space-y-2 text-xs sm:text-sm text-[#526155]">
              {VEDERA_CORE_PRODUCT.highlightPoints.map((pt, i) => (
                <li key={i} className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#87A98D] shrink-0 mt-0.5" />
                  <span>{pt}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Action CTAs */}
          <div className="space-y-3 pt-2">
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={onAddToCart}
                className="flex-1 py-3.5 px-6 bg-[#1F3D2B] text-white text-sm font-semibold rounded-xl hover:bg-[#162E20] transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Thêm vào túi mua hàng (285.000₫)</span>
              </button>

              <button
                onClick={onOpenConsultation}
                className="py-3.5 px-6 bg-[#EDF3EE] text-[#1F3D2B] border border-[#CBD5CD] text-sm font-semibold rounded-xl hover:bg-[#DEE8DF] transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-[#1F3D2B]" />
                <span>Nhận tư vấn routine</span>
              </button>
            </div>

            {/* External Pre-sell platforms */}
            <div className="p-3 bg-white rounded-xl border border-[#E8E4DF] flex items-center justify-between text-xs text-[#526155]">
              <span>Kênh mua hàng TMĐT chính hãng:</span>
              <div className="flex items-center gap-3">
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    alert('Chuyển hướng đến Shopee Mall chính thức: [Điền link gian hàng thực tế của Vedera]');
                  }}
                  className="font-medium text-[#EE4D2D] hover:underline flex items-center gap-1"
                >
                  <span>Shopee</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
                <span aria-hidden="true">·</span>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    alert('Chuyển hướng đến TikTok Shop chính thức: [Điền link TikTok Shop thực tế của Vedera]');
                  }}
                  className="font-medium text-[#111111] hover:underline flex items-center gap-1"
                >
                  <span>TikTok Shop</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>

          {/* Transparent Trust guarantee */}
          <div className="p-3.5 bg-[#FAF4ED] rounded-xl border border-[#E9DACB] text-xs text-[#6D4C2F] space-y-1">
            <p className="font-semibold flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-[#B87333]" />
              <span>Chính sách đồng hành cùng người có da nhạy cảm:</span>
            </p>
            <p className="leading-relaxed">
              Vedera tặng kèm mẫu thử nhỏ để bạn patch test trong 48h. Nếu xuất hiện kích ứng bất thường trên mẫu thử, chúng tôi hỗ trợ đổi trả nguyên seal chai 30ml theo [Chính sách đổi trả thực tế].
            </p>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* DEEP PRODUCT EXPLORER TABS */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-3xl border border-[#E8E4DF] p-6 sm:p-10 shadow-xs space-y-8">
        {/* Interactive Filter Control Tabs */}
        <div className="flex flex-wrap gap-2 border-b border-[#E8E4DF] pb-4">
          <button
            onClick={() => setActiveTab('inci')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'inci'
                ? 'bg-[#1F3D2B] text-white'
                : 'bg-[#FAF8F5] text-[#526155] hover:bg-[#EAE5DE]'
            }`}
          >
            01. Tra cứu thành phần INCI (Minh bạch 100%)
          </button>
          <button
            onClick={() => setActiveTab('patchTest')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'patchTest'
                ? 'bg-[#1F3D2B] text-white'
                : 'bg-[#FAF8F5] text-[#526155] hover:bg-[#EAE5DE]'
            }`}
          >
            02. Quy trình Patch Test 48 Giờ
          </button>
          <button
            onClick={() => setActiveTab('routine')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'routine'
                ? 'bg-[#1F3D2B] text-white'
                : 'bg-[#FAF8F5] text-[#526155] hover:bg-[#EAE5DE]'
            }`}
          >
            03. Hướng dẫn kết hợp Routine
          </button>
          <button
            onClick={() => setActiveTab('faq')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'faq'
                ? 'bg-[#1F3D2B] text-white'
                : 'bg-[#FAF8F5] text-[#526155] hover:bg-[#EAE5DE]'
            }`}
          >
            04. Đối tượng & Hỏi đáp
          </button>
        </div>

        {/* Tab 1: INCI Explorer */}
        {activeTab === 'inci' && (
          <div className="space-y-6">
            <div className="space-y-1">
              <h3 className="font-serif text-2xl font-semibold text-[#1F3D2B]">
                Bảng thành phần khoa học (Full INCI Transparency)
              </h3>
              <p className="text-xs sm:text-sm text-[#526155]">
                Bấm vào từng hoạt chất chính bên dưới để xem nguồn gốc thực tế và lý do vì sao chúng có mặt trong công thức:
              </p>
            </div>

            {/* Key Ingredient selector */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {VEDERA_CORE_PRODUCT.inciKeyIngredients.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedIngredient(idx)}
                  className={`p-3.5 text-left rounded-xl border transition-all cursor-pointer ${
                    selectedIngredient === idx
                      ? 'bg-[#EDF3EE] border-[#1F3D2B] shadow-xs'
                      : 'bg-[#FAF8F5] border-[#E8E4DF] hover:border-[#CBD5CD]'
                  }`}
                >
                  <span className="text-[11px] font-mono text-[#87A98D] block">
                    {item.scientificName}
                  </span>
                  <span className="text-sm font-semibold text-[#1F3D2B] block mt-0.5">
                    {item.name}
                  </span>
                </button>
              ))}
            </div>

            {/* Selected Ingredient Details */}
            {selectedIngredient !== null && (
              <div className="p-5 bg-[#FAF8F5] rounded-2xl border border-[#E8E4DF] space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 border-b border-[#E8E4DF] pb-2.5">
                  <div>
                    <h4 className="font-semibold text-base text-[#1F3D2B]">
                      {VEDERA_CORE_PRODUCT.inciKeyIngredients[selectedIngredient].name}
                    </h4>
                    <span className="text-xs font-mono text-[#68776B]">
                      Tên khoa học quốc tế: {VEDERA_CORE_PRODUCT.inciKeyIngredients[selectedIngredient].scientificName}
                    </span>
                  </div>
                  <span className="text-xs text-[#2C4A34] bg-[#EDF3EE] px-2.5 py-1 rounded-full w-fit">
                    Nguồn gốc: {VEDERA_CORE_PRODUCT.inciKeyIngredients[selectedIngredient].origin}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm">
                  <div>
                    <span className="font-medium text-[#1F3D2B] block mb-1">Mục đích trong công thức:</span>
                    <p className="text-[#4A574E] leading-relaxed">
                      {VEDERA_CORE_PRODUCT.inciKeyIngredients[selectedIngredient].purpose}
                    </p>
                  </div>
                  <div>
                    <span className="font-medium text-[#1F3D2B] block mb-1">Đánh giá độ an toàn cho da nhạy cảm:</span>
                    <p className="text-[#4A574E] leading-relaxed">
                      {VEDERA_CORE_PRODUCT.inciKeyIngredients[selectedIngredient].safetyNote}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Full raw INCI list */}
            <div className="p-4 bg-white rounded-xl border border-[#E8E4DF] space-y-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#1F3D2B]">
                Danh sách toàn bộ thành phần công bố (Full INCI List):
              </span>
              <p className="font-mono text-xs text-[#526155] leading-relaxed break-words bg-[#FAF8F5] p-3 rounded-lg">
                {VEDERA_CORE_PRODUCT.fullIngredientsList}
              </p>
            </div>
          </div>
        )}

        {/* Tab 2: Patch Test Guide */}
        {activeTab === 'patchTest' && (
          <div className="space-y-6">
            <div className="space-y-1">
              <h3 className="font-serif text-2xl font-semibold text-[#1F3D2B]">
                Cẩm nang Patch Test 48 Giờ tại nhà
              </h3>
              <p className="text-xs sm:text-sm text-[#526155]">
                Bước kiểm tra tối quan trọng giúp bạn an tâm trước khi thoa bất kỳ mỹ phẩm mới nào lên toàn mặt:
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {VEDERA_CORE_PRODUCT.patchTestGuide.map((step, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-2">
                  <span className="w-6 h-6 rounded-full bg-[#1F3D2B] text-white text-xs flex items-center justify-center font-semibold">
                    {idx + 1}
                  </span>
                  <p className="text-xs sm:text-sm text-[#3E4D42] leading-relaxed">
                    {step}
                  </p>
                </div>
              ))}
            </div>

            <div className="p-4 bg-[#EDF3EE] rounded-xl text-xs text-[#2A4633] space-y-1">
              <p className="font-semibold">Khi nào nên ngừng ngay lập tức?</p>
              <p className="leading-relaxed">
                Nếu xuất hiện cảm giác nóng rát kéo dài quá 15 phút, ngứa ngáy dữ dội hoặc nổi mẩn đỏ li ti tại vị trí test, hãy rửa sạch bằng nước mát và KHÔNG sử dụng sản phẩm lên mặt.
              </p>
            </div>
          </div>
        )}

        {/* Tab 3: Routine steps */}
        {activeTab === 'routine' && (
          <div className="space-y-6">
            <div className="space-y-1">
              <h3 className="font-serif text-2xl font-semibold text-[#1F3D2B]">
                Thứ tự sử dụng trong chu trình chăm sóc da
              </h3>
              <p className="text-xs sm:text-sm text-[#526155]">
                Áp dụng quy tắc từ lỏng đến đặc (thinner to thicker) để tinh chất thẩm thấu tối ưu:
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {VEDERA_CORE_PRODUCT.usageInstructions.map((st) => (
                <div key={st.stepNumber} className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-2">
                  <span className="text-xs font-mono font-semibold text-[#87A98D] block">
                    Bước {st.stepNumber}
                  </span>
                  <h4 className="font-semibold text-base text-[#1F3D2B]">
                    {st.title}
                  </h4>
                  <p className="text-xs text-[#526155] leading-relaxed">
                    {st.description}
                  </p>
                </div>
              ))}
            </div>

            <div className="p-4 bg-white rounded-xl border border-[#E8E4DF] grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-[#526155]">
              <div>
                <span className="font-semibold text-[#1F3D2B] block mb-1">Chu trình buổi sáng (Khuyến nghị):</span>
                <span>Rửa mặt dịu nhẹ → Toner cấp ẩm → <strong>Serum Vedera (3 giọt)</strong> → Kem dưỡng ẩm → Kem chống nắng SPF 50+.</span>
              </div>
              <div>
                <span className="font-semibold text-[#1F3D2B] block mb-1">Lưu ý khi dùng buổi tối:</span>
                <span>Nếu buổi tối bạn dùng Retinol hoặc BHA nồng độ cao, nên dùng Serum Vedera cách ngày hoặc dùng vào buổi sáng để tránh da quá tải.</span>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: FAQ & Suitability */}
        {activeTab === 'faq' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-semibold text-sm text-[#1F3D2B] flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-[#87A98D]" />
                  <span>Ai nên sử dụng?</span>
                </h4>
                <ul className="space-y-2 text-xs sm:text-sm text-[#526155]">
                  {VEDERA_CORE_PRODUCT.whoIsThisFor.map((item, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-[#87A98D]">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold text-sm text-[#8D493A] flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-[#8D493A]" />
                  <span>Trường hợp nên tạm hoãn hoặc tránh dùng:</span>
                </h4>
                <ul className="space-y-2 text-xs sm:text-sm text-[#526155]">
                  {VEDERA_CORE_PRODUCT.whoShouldAvoid.map((item, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-[#8D493A]">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-4 border-t border-[#E8E4DF] space-y-3">
              <h4 className="font-semibold text-sm text-[#1F3D2B]">
                Cách bảo quản tinh chất:
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-[#526155]">
                {VEDERA_CORE_PRODUCT.storageNotes.map((note, i) => (
                  <div key={i} className="p-3 rounded-lg bg-[#FAF8F5] border border-[#E8E4DF]">
                    {note}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
