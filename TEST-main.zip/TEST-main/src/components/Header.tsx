import React, { useState } from 'react';
import { ShoppingBag, Menu, X, FileText, Sparkles, ChevronRight, Share2 } from 'lucide-react';

interface HeaderProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenConsultation: () => void;
  onToggleDesignSpec: () => void;
  isDesignSpecActive: boolean;
  onOpenShareLink: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  cartCount,
  onOpenCart,
  onOpenConsultation,
  onToggleDesignSpec,
  isDesignSpecActive,
  onOpenShareLink,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'Trang chủ' },
    { id: 'about', label: 'Về Vedera' },
    { id: 'product', label: 'Sản phẩm' },
    { id: 'routine', label: 'Hướng dẫn Routine' },
    { id: 'blog', label: 'Kiến thức' },
    { id: 'faq', label: 'Hỏi đáp (FAQ)' },
    { id: 'contact', label: 'Liên hệ' },
  ];

  const handleNavClick = (id: string) => {
    onSelectTab(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F5]/95 backdrop-blur-md border-b border-[#E8E4DF] transition-all duration-200">
      {/* Top micro bar for university capstone & student/teacher notice */}
      <div className="bg-[#1F3D2B] text-[#FAF8F5] text-xs px-4 py-1.5 flex items-center justify-between">
        <div className="flex items-center gap-2 max-w-7xl mx-auto w-full justify-between">
          <div className="hidden sm:flex items-center gap-2 text-[11px] sm:text-xs">
            <span className="inline-block w-2 h-2 rounded-full bg-[#87A98D]"></span>
            <span>VEDERA SKINCARE — Thuần Chay · Nguồn Gốc Hữu Cơ · Minh Bạch Thành Phần</span>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
            <button
              onClick={onOpenShareLink}
              className="flex items-center gap-1.5 font-medium text-[11px] sm:text-xs bg-white/15 hover:bg-white/25 px-2.5 py-0.5 rounded transition-colors cursor-pointer"
              title="Xuất đường link riêng để nộp bài tập, gửi khách hàng hoặc mở tab mới"
            >
              <Share2 className="w-3.5 h-3.5 text-[#87A98D]" />
              <span>Xuất Link Riêng</span>
            </button>
            <button
              onClick={onToggleDesignSpec}
              className="flex items-center gap-1.5 font-medium text-[11px] sm:text-xs bg-white/15 hover:bg-white/25 px-2.5 py-0.5 rounded transition-colors cursor-pointer"
              title="Xem hồ sơ thiết kế, Sitemap, Wireframe & Content chi tiết phục vụ bài tập / đồ án"
            >
              <FileText className="w-3.5 h-3.5 text-[#87A98D]" />
              <span>{isDesignSpecActive ? 'Đóng Hồ Sơ Thiết Kế' : 'Hồ Sơ Thiết Kế & Wireframe'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Top Bar (Standard 3-Zone Contract) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        {/* Zone 1: Single element brand wordmark */}
        <button
          onClick={() => handleNavClick('home')}
          className="text-left group cursor-pointer focus-visible:outline-none"
        >
          <span className="font-serif text-2xl sm:text-3xl font-semibold tracking-wide text-[#1F3D2B] group-hover:text-[#162E20] transition-colors">
            VEDERA
          </span>
          <span className="block text-[10px] uppercase tracking-[0.25em] text-[#68776B] -mt-1 font-sans">
            Clean Skincare
          </span>
        </button>

        {/* Zone 2: 4-7 clean text navigation links */}
        <nav className="hidden lg:flex items-center gap-7 text-[14px] font-medium text-[#444D46]">
          {navLinks.map((link) => {
            const isActive = currentTab === link.id && !isDesignSpecActive;
            return (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`transition-colors relative py-1 focus-visible:outline-none hover:text-[#1F3D2B] ${
                  isActive
                    ? 'text-[#1F3D2B] font-semibold'
                    : 'text-[#4F5B52]'
                }`}
              >
                {link.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#1F3D2B] rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Actions (Consultation CTA + Cart/Bag Drawer) */}
        <div className="flex items-center gap-3">
          {/* Tư vấn da button */}
          <button
            onClick={onOpenConsultation}
            className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold tracking-wide uppercase text-[#1F3D2B] bg-[#EDF3EE] hover:bg-[#DEE8DF] border border-[#CBD5CD] rounded-full transition-all focus-visible:outline-none cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#1F3D2B]" />
            <span>Tư vấn da</span>
          </button>

          {/* Cart Bag icon button */}
          <button
            onClick={onOpenCart}
            className="relative p-2 text-[#2C332D] hover:text-[#1F3D2B] hover:bg-[#EAE5DE] rounded-full transition-colors focus-visible:outline-none cursor-pointer"
            aria-label="Xem giỏ hàng và đặt trước"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-[#1F3D2B] text-white text-[11px] font-bold w-4.5 h-4.5 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>

          {/* Mobile menu trigger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#2C332D] lg:hidden hover:bg-[#EAE5DE] rounded-md transition-colors"
            aria-label="Mở menu di động"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#FAF8F5] border-b border-[#E8E4DF] px-4 pt-3 pb-6 space-y-3 shadow-lg animate-in slide-in-from-top-2 duration-200">
          <div className="grid grid-cols-1 gap-1">
            {navLinks.map((link) => {
              const isActive = currentTab === link.id && !isDesignSpecActive;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`flex items-center justify-between w-full px-3 py-2.5 text-left text-sm rounded-lg transition-colors ${
                    isActive
                      ? 'bg-[#EDF3EE] text-[#1F3D2B] font-semibold'
                      : 'text-[#444D46] hover:bg-[#F2ECE4]'
                  }`}
                >
                  <span>{link.label}</span>
                  <ChevronRight className="w-4 h-4 text-[#87A98D]" />
                </button>
              );
            })}
          </div>

          <div className="pt-3 border-t border-[#E8E4DF] flex flex-col gap-2">
            <button
              onClick={() => {
                onOpenConsultation();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 text-sm font-semibold bg-[#1F3D2B] text-white rounded-xl shadow-sm hover:bg-[#162E20] transition-colors"
            >
              <Sparkles className="w-4 h-4 text-[#87A98D]" />
              <span>Đăng ký nhận tư vấn routine miễn phí</span>
            </button>
            <button
              onClick={() => {
                onOpenShareLink();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-2 text-xs font-medium bg-white text-[#1F3D2B] border border-[#CBD5CD] rounded-xl hover:bg-[#FAF8F5] transition-colors cursor-pointer"
            >
              <Share2 className="w-4 h-4 text-[#87A98D]" />
              <span>Xuất Link Riêng & Chia Sẻ Trang</span>
            </button>
            <button
              onClick={() => {
                onToggleDesignSpec();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-2 text-xs font-medium bg-[#EDF3EE] text-[#1F3D2B] border border-[#CBD5CD] rounded-xl hover:bg-[#DEE8DF] transition-colors cursor-pointer"
            >
              <FileText className="w-4 h-4 text-[#1F3D2B]" />
              <span>Xem Hồ Sơ Thiết Kế & Wireframe (Đồ án)</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
