import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Leaf,
  HeartHandshake,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  BookOpen,
  HelpCircle,
  Clock,
  Eye,
  Send,
  AlertTriangle,
  Info
} from 'lucide-react';
import {
  VEDERA_CORE_PRODUCT,
  ARTICLES_DATA,
  FAQS_DATA,
  CUSTOMER_CONCERNS,
  VEDERA_CORE_VALUES
} from '../data/vederaContent';

interface HomeViewProps {
  onSelectTab: (tab: string) => void;
  onAddToCart: () => void;
  onOpenConsultation: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onSelectTab,
  onAddToCart,
  onOpenConsultation,
}) => {
  const [openFaqId, setOpenFaqId] = useState<string | null>('faq-1');
  const [inlineSubmitted, setInlineSubmitted] = useState(false);
  const [inlineForm, setInlineForm] = useState({
    name: '',
    email: '',
    phone: '',
    skinType: 'Da nhạy cảm, dễ kích ứng',
    skinGoal: 'Làm sáng dịu nhẹ & mờ thâm',
    currentProducts: '',
    message: '',
  });

  const handleInlineSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inlineForm.name || !inlineForm.email || !inlineForm.phone) {
      alert('Vui lòng điền họ tên, email và số điện thoại để Vedera hỗ trợ bạn.');
      return;
    }
    setInlineSubmitted(true);
  };

  const toggleFaq = (id: string) => {
    setOpenFaqId(openFaqId === id ? null : id);
  };

  return (
    <div className="space-y-20 lg:space-y-28">
      {/* ========================================================================= */}
      {/* SECTION 01 – HERO */}
      {/* ========================================================================= */}
      <section className="pt-8 sm:pt-14 pb-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
            {/* Left Column: Typography & Intentional Messaging */}
            <div className="lg:col-span-6 space-y-6">
              {/* Unboxed category metadata kicker */}
              <div className="flex items-center gap-2 text-xs font-medium text-[#4D6553]">
                <span>Clean Skincare</span>
                <span aria-hidden="true">·</span>
                <span>Thuần Chay</span>
                <span aria-hidden="true">·</span>
                <span>Hữu Cơ Lành Tính</span>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl lg:text-[54px] font-semibold text-[#1F3D2B] leading-[1.15] text-balance">
                Chăm da lành tính, chọn skincare minh bạch.
              </h1>

              <p className="text-base sm:text-lg text-[#4A574E] leading-relaxed max-w-xl">
                Vedera Skincare mang đến giải pháp chăm sóc da thuần chay, hướng đến sự minh bạch trong thành phần và trải nghiệm dịu nhẹ cho làn da.
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={() => onSelectTab('product')}
                  className="px-6 py-3.5 bg-[#1F3D2B] text-white text-sm font-semibold rounded-full hover:bg-[#162E20] transition-all duration-200 shadow-sm flex items-center gap-2 cursor-pointer"
                >
                  <span>Khám phá sản phẩm</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={onOpenConsultation}
                  className="px-6 py-3.5 bg-transparent border-1.5 border-[#1F3D2B] text-[#1F3D2B] text-sm font-semibold rounded-full hover:bg-[#EDF3EE] transition-all duration-200 flex items-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-[#1F3D2B]" />
                  <span>Tư vấn chăm sóc da</span>
                </button>
              </div>

              {/* 3 Micro Trust Markers */}
              <div className="pt-4 border-t border-[#E8E4DF] grid grid-cols-3 gap-3 text-[11px] sm:text-xs text-[#526155]">
                <div className="flex items-center gap-1.5">
                  <Leaf className="w-4 h-4 text-[#87A98D] shrink-0" />
                  <span>100% Thuần chay</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <HeartHandshake className="w-4 h-4 text-[#87A98D] shrink-0" />
                  <span>Cruelty-Free</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#87A98D] shrink-0" />
                  <span>Minh bạch INCI</span>
                </div>
              </div>
            </div>

            {/* Right Column: Hero Visual Studio Shot */}
            <div className="lg:col-span-6">
              <div className="relative rounded-2xl overflow-hidden bg-[#F0EBE1] border border-[#E8E4DF] shadow-md group">
                <img
                  src="/src/assets/images/hero_serum_vedera_1790145819228.jpg"
                  alt="Chai Serum Vitamin C Vedera trên bệ đá tự nhiên trong ánh nắng ban mai"
                  referrerPolicy="no-referrer"
                  className="w-full h-[360px] sm:h-[440px] lg:h-[480px] object-cover transition-transform duration-700 group-hover:scale-102"
                />
                <div className="absolute bottom-4 left-4 right-4 bg-white/92 backdrop-blur-md p-3.5 rounded-xl border border-white/60 shadow-sm flex items-center justify-between text-xs">
                  <div>
                    <span className="font-semibold text-[#1F3D2B] block">VEDERA SERUM VITAMIN C</span>
                    <span className="text-[#68776B] text-[11px]">Dung tích: 30ml · Dẫn xuất E-AA thế hệ mới</span>
                  </div>
                  <button
                    onClick={() => onSelectTab('product')}
                    className="text-[#1F3D2B] hover:underline font-medium flex items-center gap-1"
                  >
                    <span>Chi tiết</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 02 – GIỚI THIỆU NHANH VỀ VEDERA */}
      {/* ========================================================================= */}
      <section className="py-12 bg-[#F5F0E8]/50 border-y border-[#EAE3D9]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <div className="text-xs uppercase tracking-[0.2em] font-medium text-[#68776B]">
            Câu Chuyện Thương Hiệu
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1F3D2B] text-balance">
            Vedera bắt đầu từ một lựa chọn đơn giản
          </h2>

          <p className="text-base text-[#444D46] leading-relaxed max-w-2xl mx-auto">
            Chúng tôi hiểu rằng chăm sóc da không nên là chuỗi ngày thấp thỏm lo âu mỗi khi thử một sản phẩm mới. Vedera ra đời từ mong muốn đồng hành cùng các bạn trẻ bằng những công thức thuần chay, nguồn gốc thực vật hữu cơ lành tính, tuyệt đối không thử nghiệm trên động vật và minh bạch 100% bảng thành phần. Không hoa mỹ, không phóng đại — chúng tôi tôn trọng sinh lý tự nhiên của làn da bạn.
          </p>

          {/* 5 Core Pillars unboxed presentation */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-4 text-xs font-medium text-[#2C4A34]">
            <div className="p-3 bg-white/70 rounded-xl border border-[#E3DC handle-border]">
              <span>01. Thuần chay</span>
            </div>
            <div className="p-3 bg-white/70 rounded-xl border border-[#E3DC handle-border]">
              <span>02. Nguồn gốc rõ ràng</span>
            </div>
            <div className="p-3 bg-white/70 rounded-xl border border-[#E3DC handle-border]">
              <span>03. Không thử nghiệm ĐV</span>
            </div>
            <div className="p-3 bg-white/70 rounded-xl border border-[#E3DC handle-border]">
              <span>04. Trải nghiệm dịu nhẹ</span>
            </div>
            <div className="p-3 bg-white/70 rounded-xl border border-[#E3DC handle-border] col-span-2 sm:col-span-1">
              <span>05. Minh bạch thông tin</span>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={() => onSelectTab('about')}
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#1F3D2B] hover:text-[#162E20] hover:underline cursor-pointer"
            >
              <span>Tìm hiểu về Vedera</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 03 – NỖI ĐAU KHÁCH HÀNG (Customer Pain Points) */}
      {/* ========================================================================= */}
      <section>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
              Thấu Hiểu Làn Da
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1F3D2B]">
              Skincare mới – điều gì khiến bạn lo lắng?
            </h2>
            <p className="text-sm sm:text-base text-[#526155]">
              Khi sở hữu làn da nhạy cảm hoặc lần đầu bổ sung tinh chất vào chu trình, bạn thường phải đối mặt với những băn khoăn rất thật:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 bg-white rounded-2xl border border-[#E8E4DF] space-y-3 hover:border-[#CBD5CD] transition-colors">
              <span className="font-serif text-3xl text-[#87A98D] block font-light">01</span>
              <h3 className="font-semibold text-base text-[#1F3D2B]">
                Không biết sản phẩm có phù hợp hay không
              </h3>
              <p className="text-xs sm:text-sm text-[#5F6D62] leading-relaxed">
                Mỗi làn da có cơ địa khác nhau. Rất khó để chắc chắn một sản phẩm đang "hot" trên mạng xã hội có ăn khớp với nền da của mình.
              </p>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-[#E8E4DF] space-y-3 hover:border-[#CBD5CD] transition-colors">
              <span className="font-serif text-3xl text-[#87A98D] block font-light">02</span>
              <h3 className="font-semibold text-base text-[#1F3D2B]">
                Lo ngại nguy cơ kích ứng khi đổi routine
              </h3>
              <p className="text-xs sm:text-sm text-[#5F6D62] leading-relaxed">
                Cảm giác châm chích, nổi mẩn đỏ hay bùng mụn do các hoạt chất nồng độ cao hoặc cồn khô, hương liệu nhân tạo tiềm ẩn.
              </p>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-[#E8E4DF] space-y-3 hover:border-[#CBD5CD] transition-colors">
              <span className="font-serif text-3xl text-[#87A98D] block font-light">03</span>
              <h3 className="font-semibold text-base text-[#1F3D2B]">
                Khó kiểm tra thành phần và nguồn gốc
              </h3>
              <p className="text-xs sm:text-sm text-[#5F6D62] leading-relaxed">
                Nhãn mác phức tạp, thuật ngữ hóa học khó hiểu, thông tin xuất xứ mập mờ khiến bạn không an tâm về độ an toàn thực tế.
              </p>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-[#E8E4DF] space-y-3 hover:border-[#CBD5CD] transition-colors">
              <span className="font-serif text-3xl text-[#87A98D] block font-light">04</span>
              <h3 className="font-semibold text-base text-[#1F3D2B]">
                Bị ảnh hưởng bởi review thiếu kiểm chứng
              </h3>
              <p className="text-xs sm:text-sm text-[#5F6D62] leading-relaxed">
                Các video quảng cáo quá đà hứa hẹn "trắng cấp tốc", "hết thâm sau 3 ngày" tạo kỳ vọng sai lệch và dễ gây thất vọng.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 04 – GIẢI PHÁP CỦA VEDERA */}
      {/* ========================================================================= */}
      <section className="bg-[#FAF6F0] py-14 border-y border-[#EAE3D9]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-2 max-w-xl">
              <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
                Định Hướng Thương Hiệu
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1F3D2B]">
                Một lựa chọn rõ ràng hơn cho routine của bạn
              </h2>
            </div>
            <button
              onClick={() => onSelectTab('product')}
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#1F3D2B] hover:underline cursor-pointer"
            >
              <span>Xem chi tiết sản phẩm</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {VEDERA_CORE_VALUES.slice(0, 4).map((val) => (
              <div
                key={val.code}
                className="bg-white p-6 rounded-2xl border border-[#E8E4DF] space-y-3"
              >
                <span className="text-xs font-mono font-semibold text-[#87A98D] block">
                  {val.code}.
                </span>
                <h3 className="font-semibold text-base text-[#1F3D2B]">
                  {val.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#5F6D62] leading-relaxed">
                  {val.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 05 – SẢN PHẨM NỔI BẬT (Featured Product) */}
      {/* ========================================================================= */}
      <section>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-3xl border border-[#E8E4DF] overflow-hidden shadow-xs">
            <div className="grid grid-cols-1 lg:grid-cols-12">
              {/* Product Gallery Left */}
              <div className="lg:col-span-6 bg-[#F4EFEA] p-8 sm:p-12 flex flex-col justify-between items-center relative">
                <div className="w-full flex justify-between items-center text-xs text-[#68776B]">
                  <span className="font-mono uppercase tracking-wider">VEDERA ESSENTIALS</span>
                  <span className="font-medium text-[#1F3D2B]">Dung tích 30ml</span>
                </div>

                <div className="my-6 max-w-sm w-full">
                  <img
                    src="/src/assets/images/product_serum_30ml_1790145833338.jpg"
                    alt={VEDERA_CORE_PRODUCT.name}
                    referrerPolicy="no-referrer"
                    className="w-full aspect-square object-cover rounded-2xl shadow-sm"
                  />
                </div>

                <div className="w-full grid grid-cols-3 gap-2 text-center text-[11px] text-[#526155]">
                  <div className="bg-white/80 p-2 rounded-lg border border-[#E8E4DF]">
                    <span className="block font-semibold text-[#1F3D2B]">pH 5.5 – 6.0</span>
                    <span>Cân bằng màng ẩm</span>
                  </div>
                  <div className="bg-white/80 p-2 rounded-lg border border-[#E8E4DF]">
                    <span className="block font-semibold text-[#1F3D2B]">Dẫn xuất E-AA</span>
                    <span>Ổn định, ít oxy hóa</span>
                  </div>
                  <div className="bg-white/80 p-2 rounded-lg border border-[#E8E4DF]">
                    <span className="block font-semibold text-[#1F3D2B]">0% Cồn khô</span>
                    <span>Không hương liệu nhân tạo</span>
                  </div>
                </div>
              </div>

              {/* Product Info Right */}
              <div className="lg:col-span-6 p-8 sm:p-12 flex flex-col justify-between space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-xs text-[#87A98D] font-medium">
                    <span>Sản phẩm trọng tâm</span>
                    <span aria-hidden="true">·</span>
                    <span>Serum dưỡng sáng lành tính</span>
                  </div>

                  <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1F3D2B]">
                    VEDERA VITAMIN C SERUM 30ML
                  </h2>

                  <div className="flex items-baseline gap-3">
                    <span className="text-2xl sm:text-3xl font-bold text-[#1F3D2B] tabular-nums font-mono">
                      {VEDERA_CORE_PRODUCT.price.toLocaleString('vi-VN')}₫
                    </span>
                    <span className="text-sm text-[#87A98D] line-through tabular-nums font-mono">
                      {VEDERA_CORE_PRODUCT.originalPrice?.toLocaleString('vi-VN')}₫
                    </span>
                    <span className="text-xs text-[#526155] font-medium">
                      (Đã bao gồm VAT · Tặng kèm cẩm nang Patch test)
                    </span>
                  </div>

                  <p className="text-sm text-[#4A574E] leading-relaxed">
                    {VEDERA_CORE_PRODUCT.summary}
                  </p>

                  {/* Highlights */}
                  <div className="space-y-2 pt-2">
                    <h3 className="text-xs font-semibold uppercase tracking-wider text-[#1F3D2B]">
                      Thành phần & Công dụng cốt lõi:
                    </h3>
                    <ul className="space-y-1.5 text-xs sm:text-sm text-[#526155]">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#87A98D] shrink-0 mt-0.5" />
                        <span><strong>3-O-Ethyl Ascorbic Acid (E-AA):</strong> Hỗ trợ làm đều màu da và chống oxy hóa nhẹ nhàng.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#87A98D] shrink-0 mt-0.5" />
                        <span><strong>Chiết xuất Rau má Hữu cơ:</strong> Làm dịu cảm giác ửng đỏ, hỗ trợ phục hồi màng bảo vệ da.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#87A98D] shrink-0 mt-0.5" />
                        <span><strong>Sodium Hyaluronate đa tầng + B5:</strong> Dưỡng ẩm mềm mại, ngăn ngừa tình trạng khô căng.</span>
                      </li>
                    </ul>
                  </div>

                  {/* Scientific advisory notice */}
                  <div className="p-3 bg-[#FAF8F5] rounded-xl border border-[#E8E4DF] flex items-start gap-2.5 text-xs text-[#526155]">
                    <Info className="w-4 h-4 text-[#87A98D] shrink-0 mt-0.5" />
                    <span>
                      <strong>Đối tượng phù hợp:</strong> Da xỉn màu sau mụn, da nhạy cảm muốn làm quen với tinh chất sáng da. Không áp dụng cho da đang có vết thương hở hoặc viêm dị ứng cấp tính.
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-4 border-t border-[#E8E4DF] flex flex-wrap gap-3">
                  <button
                    onClick={() => {
                      onAddToCart();
                    }}
                    className="flex-1 py-3.5 px-6 bg-[#1F3D2B] text-white text-sm font-semibold rounded-xl hover:bg-[#162E20] transition-colors cursor-pointer text-center"
                  >
                    Thêm vào túi đặt trước
                  </button>
                  <button
                    onClick={() => onSelectTab('product')}
                    className="py-3.5 px-6 bg-transparent border border-[#1F3D2B] text-[#1F3D2B] text-sm font-semibold rounded-xl hover:bg-[#EDF3EE] transition-colors cursor-pointer"
                  >
                    Xem chi tiết bảng INCI
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 06 – HOW IT WORKS (Quy trình 3 bước & Thử phản ứng) */}
      {/* ========================================================================= */}
      <section className="bg-[#FAF8F5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
              Quy Trình Khoa Học
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1F3D2B]">
              Bắt đầu routine cùng Vedera chỉ với 3 bước
            </h2>
            <p className="text-sm text-[#526155]">
              Nguyên tắc an toàn là nền tảng của làn da khỏe đẹp bền vững.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-7 rounded-2xl border border-[#E8E4DF] space-y-4">
              <div className="w-10 h-10 rounded-full bg-[#EDF3EE] text-[#1F3D2B] flex items-center justify-center font-serif text-lg font-semibold">
                1
              </div>
              <h3 className="font-semibold text-lg text-[#1F3D2B]">
                Bước 1: Kiểm tra sản phẩm
              </h3>
              <p className="text-xs sm:text-sm text-[#5F6D62] leading-relaxed">
                Đọc kỹ bảng thành phần, hạn sử dụng sau khi mở nắp (PAO) và kiểm tra các lưu ý hướng dẫn từ Vedera để đảm bảo không có thành phần bạn từng có tiền sử dị ứng.
              </p>
            </div>

            <div className="bg-white p-7 rounded-2xl border border-[#E8E4DF] space-y-4 relative border-l-4 border-l-[#87A98D]">
              <div className="w-10 h-10 rounded-full bg-[#EDF3EE] text-[#1F3D2B] flex items-center justify-center font-serif text-lg font-semibold">
                2
              </div>
              <h3 className="font-semibold text-lg text-[#1F3D2B]">
                Bước 2: Test trước khi dùng (Patch Test)
              </h3>
              <p className="text-xs sm:text-sm text-[#5F6D62] leading-relaxed">
                Thử 1 giọt nhỏ ở vùng góc xương quai hàm hoặc mặt trong cánh tay trong 24 đến 48 giờ. Theo dõi để chắc chắn không xuất hiện dấu hiệu ửng đỏ bất thường.
              </p>
            </div>

            <div className="bg-white p-7 rounded-2xl border border-[#E8E4DF] space-y-4">
              <div className="w-10 h-10 rounded-full bg-[#EDF3EE] text-[#1F3D2B] flex items-center justify-center font-serif text-lg font-semibold">
                3
              </div>
              <h3 className="font-semibold text-lg text-[#1F3D2B]">
                Bước 3: Đưa vào routine
              </h3>
              <p className="text-xs sm:text-sm text-[#5F6D62] leading-relaxed">
                Nếu da đáp ứng ổn, bắt đầu sử dụng 2 - 3 lần/tuần vào buổi sáng. Luôn kết hợp cùng kem dưỡng ẩm và kem chống nắng quang phổ rộng để bảo vệ da tốt nhất.
              </p>
            </div>
          </div>

          {/* Transparent Honest Disclaimer (As required by prompt) */}
          <div className="max-w-3xl mx-auto p-4 sm:p-5 bg-[#FAF4ED] rounded-2xl border border-[#E9DACB] flex items-start gap-3.5 text-xs sm:text-sm text-[#6D4C2F]">
            <AlertTriangle className="w-5 h-5 text-[#B87333] shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold">Lưu ý quan trọng từ Vedera:</p>
              <p className="leading-relaxed text-xs">
                Không có bất kỳ sản phẩm skincare nào có thể cam kết phù hợp 100% với mọi làn da trên thế giới. Hãy ngừng sử dụng nếu xuất hiện phản ứng bất thường và cân nhắc tham khảo ý kiến bác sĩ da liễu khi cần thiết.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 07 – SOCIAL PROOF & ĐIỀU KHÁCH HÀNG QUAN TÂM */}
      {/* ========================================================================= */}
      <section className="bg-white py-14 border-y border-[#E8E4DF]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
              Minh Bạch & Trách Nhiệm
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1F3D2B]">
              Điều khách hàng quan tâm khi lựa chọn Vedera
            </h2>
            <p className="text-sm text-[#526155]">
              Chúng tôi không tạo ra những số liệu ảo như "10.000 khách hàng" hay "98% hài lòng". Thay vào đó, Vedera cam kết bằng các bằng chứng kiểm chứng có thật:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {CUSTOMER_CONCERNS.map((item, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-2.5"
              >
                <div className="w-2 h-2 rounded-full bg-[#1F3D2B]" />
                <h3 className="font-semibold text-base text-[#1F3D2B]">
                  {item.title}
                </h3>
                <span className="text-xs font-medium text-[#87A98D] block">
                  {item.subtitle}
                </span>
                <p className="text-xs text-[#5F6D62] leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>

          {/* Genuine Customer Feedback Placeholder Banner */}
          <div className="p-6 rounded-2xl bg-[#EDF3EE] border border-[#CBD5CD] text-center space-y-2">
            <p className="text-xs sm:text-sm text-[#1F3D2B] font-medium">
              [Khu vực dành cho Feedback & Đánh giá thực tế từ nhóm khách hàng thử nghiệm sản phẩm]
            </p>
            <p className="text-xs text-[#4E6654] max-w-xl mx-auto">
              Vedera đang tổng hợp nhật ký sử dụng 28 ngày từ những người bạn tình nguyện đầu tiên. Toàn bộ hình ảnh và nhận xét sẽ được cập nhật minh bạch không qua chỉnh sửa.
            </p>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 08 – KIẾN THỨC SKINCARE (Blog Hub) */}
      {/* ========================================================================= */}
      <section>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-2 max-w-xl">
              <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
                Góc Chuyên Môn
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1F3D2B]">
                Hiểu da trước khi chọn sản phẩm
              </h2>
              <p className="text-sm text-[#526155]">
                Cung cấp kiến thức khoa học, hướng dẫn an toàn và giải mã các thành phần dưỡng da.
              </p>
            </div>
            <button
              onClick={() => onSelectTab('blog')}
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#1F3D2B] hover:underline cursor-pointer"
            >
              <span>Xem tất cả bài viết</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {ARTICLES_DATA.slice(0, 3).map((art) => (
              <article
                key={art.id}
                onClick={() => onSelectTab('blog')}
                className="bg-white rounded-2xl border border-[#E8E4DF] overflow-hidden group hover:border-[#CBD5CD] transition-all cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="aspect-16/10 overflow-hidden bg-[#F0EBE1]">
                    <img
                      src={art.thumbnail}
                      alt={art.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-5 space-y-2.5">
                    {/* Unboxed metadata */}
                    <div className="flex items-center gap-2 text-xs text-[#87A98D] font-medium">
                      <span>{art.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{art.readTime}</span>
                    </div>

                    <h3 className="font-semibold text-base text-[#1F3D2B] group-hover:text-[#162E20] leading-snug">
                      {art.title}
                    </h3>

                    <p className="text-xs text-[#5F6D62] line-clamp-2 leading-relaxed">
                      {art.summary}
                    </p>
                  </div>
                </div>

                <div className="px-5 pb-5 pt-1 flex items-center justify-between text-xs font-medium text-[#1F3D2B]">
                  <span>Đọc bài viết</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 09 – FAQ (Accordion) */}
      {/* ========================================================================= */}
      <section className="bg-[#F5F0E8]/50 py-14 border-y border-[#EAE3D9]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="text-center space-y-3">
            <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
              Giải Đáp Thắc Mắc
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1F3D2B]">
              Câu hỏi thường gặp về Serum & Chăm sóc da
            </h2>
            <p className="text-sm text-[#526155]">
              Những câu hỏi mà người có làn da nhạy cảm thường quan tâm nhất.
            </p>
          </div>

          <div className="space-y-3">
            {FAQS_DATA.map((faq) => {
              const isOpen = openFaqId === faq.id;
              return (
                <div
                  key={faq.id}
                  className="bg-white rounded-xl border border-[#E8E4DF] overflow-hidden transition-all"
                >
                  <button
                    onClick={() => toggleFaq(faq.id)}
                    className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-[#FAF8F5] transition-colors"
                  >
                    <span className="font-semibold text-sm sm:text-base text-[#1F3D2B]">
                      {faq.question}
                    </span>
                    <span className="text-[#87A98D] shrink-0">
                      {isOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </span>
                  </button>
                  {isOpen && (
                    <div className="px-4 pb-5 sm:px-5 text-xs sm:text-sm text-[#4A574E] leading-relaxed border-t border-[#F2EDE6] pt-3">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 10 – LEAD FORM / TƯ VẤN (Inline Form) */}
      {/* ========================================================================= */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl border border-[#E8E4DF] p-8 sm:p-12 shadow-xs">
          {inlineSubmitted ? (
            <div className="text-center py-8 space-y-4">
              <div className="w-16 h-16 bg-[#EDF3EE] text-[#1F3D2B] rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <h3 className="font-serif text-3xl font-semibold text-[#1F3D2B]">
                Vedera đã nhận được thông tin.
              </h3>
              <p className="text-sm text-[#526155] max-w-md mx-auto leading-relaxed">
                Cảm ơn <strong>{inlineForm.name}</strong> đã quan tâm đến Vedera Skincare. Đội ngũ chuyên viên sẽ xem xét tình trạng da của bạn và gửi tư vấn chi tiết trong 24 giờ.
              </p>
              <button
                onClick={() => setInlineSubmitted(false)}
                className="px-6 py-2.5 bg-[#1F3D2B] text-white text-xs font-semibold rounded-full hover:bg-[#162E20] transition-colors cursor-pointer"
              >
                Gửi thêm câu hỏi khác
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="text-center space-y-2">
                <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
                  Đồng Hành Cá Nhân Hóa
                </span>
                <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1F3D2B]">
                  Chưa biết sản phẩm nào phù hợp với routine của bạn?
                </h2>
                <p className="text-sm text-[#526155] max-w-xl mx-auto">
                  Để lại một vài thông tin để Vedera hỗ trợ bạn tìm hiểu sản phẩm phù hợp hơn.
                </p>
              </div>

              <form onSubmit={handleInlineSubmit} className="space-y-4 pt-2">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block text-xs font-medium text-[#444D46] mb-1">
                      Họ và tên *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Họ tên của bạn"
                      value={inlineForm.name}
                      onChange={(e) => setInlineForm({ ...inlineForm, name: e.target.value })}
                      className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-[#FAF8F5] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#444D46] mb-1">
                      Email liên hệ *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="Email nhận lời khuyên"
                      value={inlineForm.email}
                      onChange={(e) => setInlineForm({ ...inlineForm, email: e.target.value })}
                      className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-[#FAF8F5] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#444D46] mb-1">
                      Số điện thoại *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="Số điện thoại / Zalo"
                      value={inlineForm.phone}
                      onChange={(e) => setInlineForm({ ...inlineForm, phone: e.target.value })}
                      className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-[#FAF8F5] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block text-xs font-medium text-[#444D46] mb-1">
                      Tình trạng da
                    </label>
                    <select
                      value={inlineForm.skinType}
                      onChange={(e) => setInlineForm({ ...inlineForm, skinType: e.target.value })}
                      className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-[#FAF8F5] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                    >
                      <option value="Da nhạy cảm, dễ kích ứng">Da nhạy cảm, dễ kích ứng</option>
                      <option value="Da dầu thiếu ẩm, lỗ chân lông to">Da dầu thiếu ẩm</option>
                      <option value="Da khô ráp, dễ bong tróc">Da khô ráp, dễ bong tróc</option>
                      <option value="Da hỗn hợp, có vết thâm mụn">Da hỗn hợp, có vết thâm mụn</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#444D46] mb-1">
                      Mục tiêu chăm sóc da
                    </label>
                    <select
                      value={inlineForm.skinGoal}
                      onChange={(e) => setInlineForm({ ...inlineForm, skinGoal: e.target.value })}
                      className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-[#FAF8F5] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                    >
                      <option value="Làm sáng dịu nhẹ & mờ thâm">Làm sáng dịu nhẹ & mờ thâm</option>
                      <option value="Củng cố màng ẩm hàng rào da">Củng cố màng ẩm hàng rào da</option>
                      <option value="Tập làm quen với Vitamin C an toàn">Tập làm quen với Vitamin C</option>
                      <option value="Tối giản chu trình skincare">Tối giản chu trình skincare</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#444D46] mb-1">
                    Sản phẩm đang sử dụng hiện tại
                  </label>
                  <input
                    type="text"
                    placeholder="Ví dụ: Đang dùng sữa rửa mặt tạo bọt dịu nhẹ, kem dưỡng ẩm B5..."
                    value={inlineForm.currentProducts}
                    onChange={(e) => setInlineForm({ ...inlineForm, currentProducts: e.target.value })}
                    className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-[#FAF8F5] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#444D46] mb-1">
                    Nội dung cần tư vấn
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Mô tả cụ thể những băn khoăn hoặc phản ứng da trước đây của bạn..."
                    value={inlineForm.message}
                    onChange={(e) => setInlineForm({ ...inlineForm, message: e.target.value })}
                    className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-[#FAF8F5] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full sm:w-auto px-8 py-3.5 bg-[#1F3D2B] text-white text-sm font-semibold rounded-full hover:bg-[#162E20] transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                  >
                    <Send className="w-4 h-4" />
                    <span>Đăng ký tư vấn</span>
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 11 – CTA CUỐI TRANG (No FOMO / Pre-Sell Anchor) */}
      {/* ========================================================================= */}
      <section className="pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#F0ECE4] rounded-3xl p-8 sm:p-14 text-center border border-[#E2DDD3] space-y-6">
            <div className="space-y-3 max-w-xl mx-auto">
              <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
                Lựa Chọn Bền Vững
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#1F3D2B] text-balance">
                Hiểu làn da. Chọn skincare có cơ sở.
              </h2>
              <p className="text-sm sm:text-base text-[#444D46] leading-relaxed">
                Đồng hành cùng hàng nghìn bạn trẻ trên hành trình chăm sóc làn da dịu lành, tôn trọng thiên nhiên và nói không với các cam kết phi thực tế.
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
              <button
                onClick={() => onSelectTab('product')}
                className="px-8 py-3.5 bg-[#1F3D2B] text-white text-sm font-semibold rounded-full hover:bg-[#162E20] transition-colors shadow-sm cursor-pointer"
              >
                Khám phá Vedera
              </button>
              <button
                onClick={onOpenConsultation}
                className="px-8 py-3.5 bg-transparent border-1.5 border-[#1F3D2B] text-[#1F3D2B] text-sm font-semibold rounded-full hover:bg-white/60 transition-colors cursor-pointer"
              >
                Nhận tư vấn
              </button>
            </div>

            <p className="text-[11px] text-[#68776B] pt-2">
              Không cam kết thần thánh hóa · Minh bạch nguồn gốc · Hỗ trợ kiểm tra phản ứng da 1-1
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};
