import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { ConsultationModal } from './components/ConsultationModal';
import { ShareLinkModal } from './components/ShareLinkModal';
import { HomeView } from './views/HomeView';
import { AboutView } from './views/AboutView';
import { ProductDetailView } from './views/ProductDetailView';
import { RoutineGuideView } from './views/RoutineGuideView';
import { BlogView } from './views/BlogView';
import { FaqView } from './views/FaqView';
import { ContactView } from './views/ContactView';
import { DesignSpecView } from './views/DesignSpecView';
import { ShoppingBag, Sparkles, CheckCircle2 } from 'lucide-react';
import { VEDERA_CORE_PRODUCT } from './data/vederaContent';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [isDesignSpecActive, setIsDesignSpecActive] = useState<boolean>(false);
  const [cartOpen, setCartOpen] = useState<boolean>(false);
  const [cartCount, setCartCount] = useState<number>(1);
  const [consultationOpen, setConsultationOpen] = useState<boolean>(false);
  const [shareModalOpen, setShareModalOpen] = useState<boolean>(false);
  const [showToast, setShowToast] = useState<string | null>(null);

  // Sync state from URL hash on load & hashchange
  useEffect(() => {
    const handleHashSync = () => {
      const hash = window.location.hash.replace('#', '').trim().toLowerCase();
      if (hash === 'design-spec' || hash === 'spec') {
        setIsDesignSpecActive(true);
      } else if (['home', 'about', 'product', 'routine', 'blog', 'faq', 'contact'].includes(hash)) {
        setIsDesignSpecActive(false);
        setCurrentTab(hash);
      }
    };

    handleHashSync();
    window.addEventListener('hashchange', handleHashSync);
    return () => window.removeEventListener('hashchange', handleHashSync);
  }, []);

  // Update URL hash when tab or design spec state changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });

    if (isDesignSpecActive) {
      if (window.location.hash !== '#design-spec') {
        window.history.replaceState(null, '', '#design-spec');
      }
    } else {
      if (window.location.hash !== `#${currentTab}`) {
        window.history.replaceState(null, '', `#${currentTab}`);
      }
    }
  }, [currentTab, isDesignSpecActive]);

  const handleAddToCart = () => {
    setCartCount((prev) => prev + 1);
    setCartOpen(true);
    triggerToast('Đã thêm Serum Vitamin C 30ml vào túi hàng!');
  };

  const triggerToast = (msg: string) => {
    setShowToast(msg);
    setTimeout(() => {
      setShowToast(null);
    }, 2800);
  };

  const handleSelectTab = (tab: string) => {
    setCurrentTab(tab);
    setIsDesignSpecActive(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-[#2C332D] font-sans">
      {/* Header */}
      <Header
        currentTab={currentTab}
        onSelectTab={handleSelectTab}
        cartCount={cartCount}
        onOpenCart={() => setCartOpen(true)}
        onOpenConsultation={() => setConsultationOpen(true)}
        onToggleDesignSpec={() => setIsDesignSpecActive(!isDesignSpecActive)}
        isDesignSpecActive={isDesignSpecActive}
        onOpenShareLink={() => setShareModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {isDesignSpecActive ? (
          <DesignSpecView />
        ) : (
          <>
            {currentTab === 'home' && (
              <HomeView
                onSelectTab={handleSelectTab}
                onAddToCart={handleAddToCart}
                onOpenConsultation={() => setConsultationOpen(true)}
              />
            )}
            {currentTab === 'about' && (
              <AboutView
                onSelectTab={handleSelectTab}
                onOpenConsultation={() => setConsultationOpen(true)}
              />
            )}
            {currentTab === 'product' && (
              <ProductDetailView
                onAddToCart={handleAddToCart}
                onOpenConsultation={() => setConsultationOpen(true)}
                onSelectTab={handleSelectTab}
              />
            )}
            {currentTab === 'routine' && (
              <RoutineGuideView
                onOpenConsultation={() => setConsultationOpen(true)}
                onSelectTab={handleSelectTab}
              />
            )}
            {currentTab === 'blog' && (
              <BlogView onOpenConsultation={() => setConsultationOpen(true)} />
            )}
            {currentTab === 'faq' && (
              <FaqView onOpenConsultation={() => setConsultationOpen(true)} />
            )}
            {currentTab === 'contact' && <ContactView />}
          </>
        )}
      </main>

      {/* Floating Mobile Action Bar (Sticky <= 15% Viewport Cap) */}
      {!isDesignSpecActive && (currentTab === 'home' || currentTab === 'product') && (
        <div className="sm:hidden fixed bottom-0 left-0 right-0 z-30 bg-[#FAF8F5]/96 backdrop-blur-md border-t border-[#E8E4DF] p-3 shadow-lg flex items-center gap-2">
          <button
            onClick={() => setConsultationOpen(true)}
            className="flex-1 py-2.5 px-3 bg-[#EDF3EE] text-[#1F3D2B] border border-[#CBD5CD] rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Tư vấn da</span>
          </button>
          <button
            onClick={handleAddToCart}
            className="flex-1 py-2.5 px-3 bg-[#1F3D2B] text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 hover:bg-[#162E20] transition-colors cursor-pointer"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Đặt Serum (285k)</span>
          </button>
        </div>
      )}

      {/* Quick Toast Notification */}
      {showToast && (
        <div className="fixed bottom-18 sm:bottom-6 right-4 sm:right-6 z-50 bg-[#1F3D2B] text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2.5 text-xs animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-[#87A98D]" />
          <span>{showToast}</span>
        </div>
      )}

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        quantity={cartCount}
        onUpdateQuantity={(qty) => setCartCount(qty)}
        onOpenConsultation={() => {
          setCartOpen(false);
          setConsultationOpen(true);
        }}
      />

      {/* Consultation Modal */}
      <ConsultationModal
        isOpen={consultationOpen}
        onClose={() => setConsultationOpen(false)}
      />

      {/* Share Link Modal */}
      <ShareLinkModal
        isOpen={shareModalOpen}
        onClose={() => setShareModalOpen(false)}
        currentTab={currentTab}
        isDesignSpecActive={isDesignSpecActive}
      />

      {/* Footer */}
      <Footer
        onSelectTab={handleSelectTab}
        onOpenConsultation={() => setConsultationOpen(true)}
        onToggleDesignSpec={() => setIsDesignSpecActive(!isDesignSpecActive)}
      />
    </div>
  );
}
