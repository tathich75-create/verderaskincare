import React, { useState } from 'react';
import {
  ShieldAlert,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Calendar,
  Sparkles,
  ArrowRight,
  Clock,
  Droplet
} from 'lucide-react';

interface RoutineGuideViewProps {
  onOpenConsultation: () => void;
  onSelectTab: (tab: string) => void;
}

export const RoutineGuideView: React.FC<RoutineGuideViewProps> = ({
  onOpenConsultation,
  onSelectTab,
}) => {
  const [selectedIngredientCheck, setSelectedIngredientCheck] = useState<string>('bha');

  const compatibilityData: Record<
    string,
    { name: string; status: 'ok' | 'caution' | 'avoid'; advice: string }
  > = {
    ha: {
      name: 'Hyaluronic Acid (HA)',
      status: 'ok',
      advice: 'Phối hợp rất tốt. HA cấp nước đa tầng giúp da ẩm mọng, tạo nền tảng màng ẩm khỏe mạnh để hấp thu dẫn xuất Vitamin C E-AA hiệu quả hơn.'
    },
    niacinamide: {
      name: 'Niacinamide (Vitamin B3)',
      status: 'ok',
      advice: 'Với dẫn xuất 3-O-Ethyl Ascorbic Acid (E-AA) hoạt động ở pH 5.5-6.0, bạn hoàn toàn có thể dùng chung với Niacinamide mà không sợ phản ứng ngả đỏ da như L-AA truyền thống.'
    },
    bha: {
      name: 'BHA (Salicylic Acid) / AHA',
      status: 'caution',
      advice: 'Cần cẩn trọng. Nếu da nhạy cảm, KHÔNG NÊN bôi cùng lúc trong một buổi. Khuyến nghị: Dùng Serum Vitamin C vào buổi sáng và dùng AHA/BHA vào buổi tối (cách ngày).'
    },
    retinol: {
      name: 'Retinol / Tretinoin',
      status: 'caution',
      advice: 'Hai hoạt chất đều có hoạt tính sinh học mạnh. Khuyến nghị tách buổi rõ ràng: Serum Vitamin C dùng buổi sáng + kem chống nắng; Retinol dùng buổi tối kèm kem dưỡng phục hồi B5.'
    },
    peel: {
      name: 'Peel da sinh học nồng độ cao',
      status: 'avoid',
      advice: 'Tạm ngưng dùng Vitamin C ít nhất 3-5 ngày sau khi thực hiện peel da hoặc trị liệu xâm lấn, chỉ tập trung phục hồi bằng dưỡng ẩm lành tính đến khi da lành hẳn.'
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-16">
      {/* Header */}
      <div className="max-w-3xl mx-auto text-center space-y-4">
        <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
          Cẩm Nang Chăm Da Khoa Học
        </span>
        <h1 className="font-serif text-4xl sm:text-5xl font-semibold text-[#1F3D2B]">
          Hướng dẫn sử dụng & Quy trình Patch Test
        </h1>
        <p className="text-sm sm:text-base text-[#526155] leading-relaxed">
          Không bao giờ vội vàng khi chăm sóc làn da nhạy cảm. Hãy lắng nghe phản ứng màng ẩm và làm quen từng bước có cơ sở.
        </p>
      </div>

      {/* 1. Patch Test Protocol 48h (Visual Guide) */}
      <section className="bg-white rounded-3xl border border-[#E8E4DF] p-6 sm:p-10 shadow-xs space-y-8">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase text-[#87A98D]">
            <span>Quy Trình Chuẩn Da Liễu</span>
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-[#1F3D2B]">
            Quy trình Patch Test (Kiểm tra phản ứng) 48 Giờ
          </h2>
          <p className="text-xs sm:text-sm text-[#526155]">
            Áp dụng cho mọi mỹ phẩm dưỡng da mới trước khi thoa lên diện rộng:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
            <span className="w-8 h-8 rounded-full bg-[#1F3D2B] text-white text-xs font-bold flex items-center justify-center">
              01
            </span>
            <h3 className="font-semibold text-sm text-[#1F3D2B]">
              Vệ sinh vùng thử
            </h3>
            <p className="text-xs text-[#5F6D62] leading-relaxed">
              Làm sạch một vùng da nhỏ ở góc xương quai hàm (ngay dưới tai) hoặc mặt trong cánh tay. Lau khô nhẹ nhàng.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
            <span className="w-8 h-8 rounded-full bg-[#1F3D2B] text-white text-xs font-bold flex items-center justify-center">
              02
            </span>
            <h3 className="font-semibold text-sm text-[#1F3D2B]">
              Chấm 1 giọt nhỏ
            </h3>
            <p className="text-xs text-[#5F6D62] leading-relaxed">
              Lấy 1 giọt serum Vedera (khoảng bằng hạt đậu xanh) chấm đều lên diện tích 2x2 cm và để khô tự nhiên.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
            <span className="w-8 h-8 rounded-full bg-[#1F3D2B] text-white text-xs font-bold flex items-center justify-center">
              03
            </span>
            <h3 className="font-semibold text-sm text-[#1F3D2B]">
              Theo dõi 24 – 48 giờ
            </h3>
            <p className="text-xs text-[#5F6D62] leading-relaxed">
              Giữ nguyên không rửa trong 24h. Quan sát xem có biểu hiện ngứa rát, ửng đỏ hoặc nổi mụn nước li ti hay không.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
            <span className="w-8 h-8 rounded-full bg-[#1F3D2B] text-white text-xs font-bold flex items-center justify-center">
              04
            </span>
            <h3 className="font-semibold text-sm text-[#1F3D2B]">
              Đánh giá kết quả
            </h3>
            <p className="text-xs text-[#5F6D62] leading-relaxed">
              Nếu bề mặt da hoàn toàn êm dịu, bạn có thể tự tin bổ sung serum vào chu trình chăm sóc da mặt của mình.
            </p>
          </div>
        </div>

        {/* Warning Callout */}
        <div className="p-4 bg-[#FAF4ED] rounded-xl border border-[#E9DACB] flex items-start gap-3 text-xs text-[#6D4C2F]">
          <ShieldAlert className="w-5 h-5 text-[#B87333] shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold block mb-0.5">Xử lý khi có phản ứng bất thường:</span>
            <span>
              Nếu da đỏ bừng, ngứa rát hoặc nổi mẩn, hãy rửa sạch ngay bằng nước muối sinh lý hoặc nước mát. Tạm dừng sản phẩm và liên hệ hotline Vedera hoặc bác sĩ da liễu để được hỗ trợ chuyên sâu.
            </span>
          </div>
        </div>
      </section>

      {/* 2. Interactive Active Ingredient Compatibility Checker */}
      <section className="bg-white rounded-3xl border border-[#E8E4DF] p-6 sm:p-10 shadow-xs space-y-8">
        <div className="space-y-2">
          <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
            Tra Cứu Tương Thích Hoạt Chất
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-[#1F3D2B]">
            Kết hợp Serum Vedera với các thành phần khác như thế nào?
          </h2>
          <p className="text-xs sm:text-sm text-[#526155]">
            Chọn hoạt chất bạn đang có trong chu trình để nhận khuyến nghị phối hợp an toàn:
          </p>
        </div>

        {/* Interactive buttons */}
        <div className="flex flex-wrap gap-2">
          {Object.entries(compatibilityData).map(([key, val]) => (
            <button
              key={key}
              onClick={() => setSelectedIngredientCheck(key)}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                selectedIngredientCheck === key
                  ? 'bg-[#1F3D2B] text-white shadow-xs'
                  : 'bg-[#FAF8F5] text-[#526155] border border-[#E8E4DF] hover:border-[#CBD5CD]'
              }`}
            >
              {val.name}
            </button>
          ))}
        </div>

        {/* Result display */}
        {selectedIngredientCheck && (
          <div className="p-6 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
            <div className="flex items-center gap-2">
              {compatibilityData[selectedIngredientCheck].status === 'ok' ? (
                <div className="flex items-center gap-1.5 text-xs font-semibold text-[#2C4A34] bg-[#EDF3EE] px-2.5 py-1 rounded-full">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#1F3D2B]" />
                  <span>Tương thích tốt (Có thể kết hợp)</span>
                </div>
              ) : compatibilityData[selectedIngredientCheck].status === 'caution' ? (
                <div className="flex items-center gap-1.5 text-xs font-semibold text-[#875C36] bg-[#FAF4ED] px-2.5 py-1 rounded-full">
                  <ShieldAlert className="w-3.5 h-3.5 text-[#B87333]" />
                  <span>Cần tách buổi (Sáng - Tối)</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-xs font-semibold text-[#8D493A] bg-[#FDF0ED] px-2.5 py-1 rounded-full">
                  <XCircle className="w-3.5 h-3.5 text-[#8D493A]" />
                  <span>Tránh dùng chung</span>
                </div>
              )}
              <span className="font-semibold text-sm text-[#1F3D2B]">
                {compatibilityData[selectedIngredientCheck].name}
              </span>
            </div>

            <p className="text-xs sm:text-sm text-[#444D46] leading-relaxed">
              {compatibilityData[selectedIngredientCheck].advice}
            </p>
          </div>
        )}
      </section>

      {/* 3. 14-Day Introductory Calendar */}
      <section className="bg-white rounded-3xl border border-[#E8E4DF] p-6 sm:p-10 shadow-xs space-y-8">
        <div className="space-y-2">
          <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
            Lịch Trình Làm Quen Da
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-[#1F3D2B]">
            Lộ trình 14 ngày đầu tiên cho da nhạy cảm
          </h2>
          <p className="text-xs sm:text-sm text-[#526155]">
            Kiên nhẫn là chìa khóa để hàng rào da làm quen với chất chống oxy hóa tự nhiên:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
            <div className="flex items-center justify-between text-xs text-[#87A98D] font-mono">
              <span>TUẦN 01</span>
              <span>2 Lần / Tuần</span>
            </div>
            <h4 className="font-semibold text-base text-[#1F3D2B]">
              Thử nghiệm & Khởi động
            </h4>
            <p className="text-xs text-[#5F6D62] leading-relaxed">
              Sau khi patch test thành công, thoa 2-3 giọt vào sáng Thứ 3 và Thứ 6. Luôn thoa kem dưỡng ẩm làm dịu và kem chống nắng.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
            <div className="flex items-center justify-between text-xs text-[#87A98D] font-mono">
              <span>TUẦN 02</span>
              <span>3 Lần / Tuần</span>
            </div>
            <h4 className="font-semibold text-base text-[#1F3D2B]">
              Tăng dần tần suất
            </h4>
            <p className="text-xs text-[#5F6D62] leading-relaxed">
              Nếu da mềm mượt và không có cảm giác khó chịu, tăng lên dùng cách ngày (Thứ 2, Thứ 4, Thứ 6). Lắng nghe độ ẩm của bề mặt da.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
            <div className="flex items-center justify-between text-xs text-[#87A98D] font-mono">
              <span>TỪ TUẦN 03</span>
              <span>Hàng ngày</span>
            </div>
            <h4 className="font-semibold text-base text-[#1F3D2B]">
              Duy trì bảo vệ ổn định
            </h4>
            <p className="text-xs text-[#5F6D62] leading-relaxed">
              Khi da đã thích ứng hoàn toàn, có thể dùng đều đặn mỗi buổi sáng trước kem chống nắng để chống lại gốc tự do và làm sáng đều màu da.
            </p>
          </div>
        </div>

        <div className="pt-2 flex justify-center">
          <button
            onClick={onOpenConsultation}
            className="px-6 py-3 bg-[#1F3D2B] text-white text-xs font-semibold rounded-full hover:bg-[#162E20] transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-[#87A98D]" />
            <span>Bạn vẫn còn băn khoăn? Nhận tư vấn routine riêng</span>
          </button>
        </div>
      </section>
    </div>
  );
};
