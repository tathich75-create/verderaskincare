import React, { useState } from 'react';
import {
  FileText,
  Copy,
  Check,
  Layout,
  Palette,
  Layers,
  Smartphone,
  Cpu,
  ArrowRight,
  ExternalLink,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import {
  WIREFRAME_SECTIONS_SPEC,
  DESIGN_SYSTEM_SPEC,
  UX_FLOW_SPEC,
  TECHNICAL_RECOMMENDATIONS,
  SectionSpec
} from '../data/designSpecDoc';

export const DesignSpecView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'wireframe' | 'sitemap' | 'uxflow' | 'designSystem' | 'tech'>('wireframe');
  const [copiedSectionIndex, setCopiedSectionIndex] = useState<number | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);

  const handleCopySection = (sec: SectionSpec, idx: number) => {
    const text = `TÊN SECTION: ${sec.name}\n\n1. MỤC TIÊU:\n${sec.goal}\n\n2. NỘI DUNG (CONTENT COPY):\n${sec.contentCopy}\n\n3. CTA ĐỀ XUẤT:\n${sec.ctaText}\n\n4. HÌNH ẢNH ĐỀ XUẤT:\n${sec.imageSuggestion}\n\n5. LƯU Ý UX/UI:\n${sec.uxUiNotes}\n---------------------------------------\n`;
    navigator.clipboard?.writeText(text);
    setCopiedSectionIndex(idx);
    setTimeout(() => setCopiedSectionIndex(null), 2000);
  };

  const handleCopyAllSpecs = () => {
    const allText = WIREFRAME_SECTIONS_SPEC.map(
      (sec) =>
        `TÊN SECTION: ${sec.name}\n\n1. MỤC TIÊU:\n${sec.goal}\n\n2. NỘI DUNG:\n${sec.contentCopy}\n\n3. CTA:\n${sec.ctaText}\n\n4. HÌNH ẢNH ĐỀ XUẤT:\n${sec.imageSuggestion}\n\n5. LƯU Ý UX/UI:\n${sec.uxUiNotes}\n`
    ).join('\n=========================================\n\n');
    navigator.clipboard?.writeText(allText);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
      {/* Banner / Header */}
      <div className="p-6 sm:p-8 bg-[#1F3D2B] rounded-3xl text-white space-y-4 shadow-md">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <span className="text-xs uppercase tracking-wider text-[#87A98D] font-mono block">
              BỘ HỒ SƠ THIẾT KẾ WEBSITE TOÀN DIỆN (ACADEMIC SPECIFICATION)
            </span>
            <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-white mt-1">
              Hồ Sơ Thiết Kế VEDERA SKINCARE
            </h1>
          </div>

          <button
            onClick={handleCopyAllSpecs}
            className="px-5 py-2.5 bg-white text-[#1F3D2B] text-xs font-semibold rounded-xl hover:bg-[#FAF8F5] transition-colors flex items-center gap-2 cursor-pointer shadow-sm"
          >
            {copiedAll ? <Check className="w-4 h-4 text-[#1F3D2B]" /> : <Copy className="w-4 h-4 text-[#1F3D2B]" />}
            <span>{copiedAll ? 'Đã sao chép toàn bộ!' : 'Sao chép toàn bộ Content & Wireframe'}</span>
          </button>
        </div>

        <p className="text-xs sm:text-sm text-[#D1DDD3] leading-relaxed max-w-3xl">
          Tài liệu chuẩn mực phục vụ bài tập lớn / đồ án đại học và bàn giao thiết kế (Handover). Định dạng theo format: <strong>Tên section → Mục tiêu → Nội dung → CTA → Hình ảnh đề xuất → Lưu ý UX/UI</strong>. Tuân thủ 3 trụ cột: <strong>MINH BẠCH – THUẦN CHAY – CHĂM DA CÓ CƠ SỞ</strong>.
        </p>
      </div>

      {/* Tabs navigation */}
      <div className="flex flex-wrap gap-2 border-b border-[#E8E4DF] pb-4">
        <button
          onClick={() => setActiveTab('wireframe')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
            activeTab === 'wireframe'
              ? 'bg-[#1F3D2B] text-white shadow-xs'
              : 'bg-white text-[#4A574E] border border-[#E8E4DF] hover:border-[#CBD5CD]'
          }`}
        >
          <Layout className="w-4 h-4" />
          <span>B & C. Wireframe & Content chi tiết từng Section</span>
        </button>

        <button
          onClick={() => setActiveTab('sitemap')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
            activeTab === 'sitemap'
              ? 'bg-[#1F3D2B] text-white shadow-xs'
              : 'bg-white text-[#4A574E] border border-[#E8E4DF] hover:border-[#CBD5CD]'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>A. Sitemap (Cấu trúc Website)</span>
        </button>

        <button
          onClick={() => setActiveTab('uxflow')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
            activeTab === 'uxflow'
              ? 'bg-[#1F3D2B] text-white shadow-xs'
              : 'bg-white text-[#4A574E] border border-[#E8E4DF] hover:border-[#CBD5CD]'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>D & E. CTA Matrix & UX Flow</span>
        </button>

        <button
          onClick={() => setActiveTab('designSystem')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
            activeTab === 'designSystem'
              ? 'bg-[#1F3D2B] text-white shadow-xs'
              : 'bg-white text-[#4A574E] border border-[#E8E4DF] hover:border-[#CBD5CD]'
          }`}
        >
          <Palette className="w-4 h-4" />
          <span>F. Design System & Bảng màu</span>
        </button>

        <button
          onClick={() => setActiveTab('tech')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
            activeTab === 'tech'
              ? 'bg-[#1F3D2B] text-white shadow-xs'
              : 'bg-white text-[#4A574E] border border-[#E8E4DF] hover:border-[#CBD5CD]'
          }`}
        >
          <Cpu className="w-4 h-4" />
          <span>G & H. Responsive & Đề xuất Kỹ Thuật</span>
        </button>
      </div>

      {/* Tab 1: Wireframe & Content Spec */}
      {activeTab === 'wireframe' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <span className="text-xs text-[#68776B]">
              Hiển thị đầy đủ 12 Sections của Website chuẩn format bài tập đại học
            </span>
            <span className="text-xs font-mono text-[#1F3D2B] bg-[#EDF3EE] px-2.5 py-1 rounded">
              12 / 12 Sections Verified
            </span>
          </div>

          <div className="space-y-6">
            {WIREFRAME_SECTIONS_SPEC.map((sec, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl border border-[#E8E4DF] p-6 sm:p-8 space-y-5 shadow-2xs hover:border-[#CBD5CD] transition-all"
              >
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#E8E4DF] pb-4">
                  <h3 className="font-serif text-xl sm:text-2xl font-semibold text-[#1F3D2B]">
                    {sec.name}
                  </h3>
                  <button
                    onClick={() => handleCopySection(sec, idx)}
                    className="px-3.5 py-1.5 bg-[#FAF8F5] border border-[#CBD5CD] hover:bg-[#EDF3EE] text-[#1F3D2B] text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    {copiedSectionIndex === idx ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-[#1F3D2B]" />
                        <span>Đã chép</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-[#68776B]" />
                        <span>Chép Section này</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 text-xs sm:text-sm">
                  {/* Left col: Goal & Copy */}
                  <div className="md:col-span-7 space-y-4">
                    <div>
                      <span className="font-semibold text-[#87A98D] uppercase tracking-wider text-[11px] block mb-1">
                        1. Mục tiêu Section:
                      </span>
                      <p className="text-[#2C332D] leading-relaxed bg-[#FAF8F5] p-3 rounded-xl border border-[#E8E4DF]">
                        {sec.goal}
                      </p>
                    </div>

                    <div>
                      <span className="font-semibold text-[#87A98D] uppercase tracking-wider text-[11px] block mb-1">
                        2. Nội dung (Content Copy có thể copy trực tiếp):
                      </span>
                      <pre className="font-sans whitespace-pre-wrap text-xs text-[#3E4D42] bg-[#FAF8F5] p-4 rounded-xl border border-[#E8E4DF] leading-relaxed">
                        {sec.contentCopy}
                      </pre>
                    </div>
                  </div>

                  {/* Right col: CTA, Image, UX/UI Notes */}
                  <div className="md:col-span-5 space-y-4 border-t md:border-t-0 md:border-l border-[#E8E4DF] md:pl-6 pt-4 md:pt-0">
                    <div>
                      <span className="font-semibold text-[#1F3D2B] block text-xs mb-1">
                        3. Đề xuất CTA:
                      </span>
                      <p className="text-[#526155] text-xs leading-relaxed">
                        {sec.ctaText}
                      </p>
                    </div>

                    <div>
                      <span className="font-semibold text-[#1F3D2B] block text-xs mb-1">
                        4. Hình ảnh đề xuất:
                      </span>
                      <p className="text-[#526155] text-xs leading-relaxed">
                        {sec.imageSuggestion}
                      </p>
                    </div>

                    <div>
                      <span className="font-semibold text-[#1F3D2B] block text-xs mb-1">
                        5. Lưu ý UX/UI & Phong cách:
                      </span>
                      <p className="text-[#526155] text-xs leading-relaxed bg-[#EDF3EE]/60 p-2.5 rounded-lg border border-[#D5E0D7]">
                        {sec.uxUiNotes}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 2: Sitemap */}
      {activeTab === 'sitemap' && (
        <div className="bg-white rounded-3xl border border-[#E8E4DF] p-6 sm:p-10 shadow-xs space-y-6">
          <div className="space-y-1">
            <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-[#1F3D2B]">
              A. SITEMAP KIẾN TRÚC THÔNG TIN WEBSITE VEDERA SKINCARE
            </h2>
            <p className="text-xs sm:text-sm text-[#526155]">
              Cấu trúc đa trang tối ưu kết hợp giữa Informational/Microsite và Pre-sell Landing Page:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-4">
            <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
              <span className="text-xs font-mono font-bold text-[#1F3D2B]">1. TRANG CHỦ (Home)</span>
              <ul className="text-xs text-[#526155] space-y-1.5 pl-3 border-l-2 border-[#87A98D]">
                <li>• Section 01: Hero Banner</li>
                <li>• Section 02: Giới thiệu nhanh Vedera</li>
                <li>• Section 03: Nỗi đau khách hàng</li>
                <li>• Section 04: Giải pháp 4 cam kết</li>
                <li>• Section 05: Serum Vitamin C 30ml</li>
                <li>• Section 06: How It Works (3 bước)</li>
                <li>• Section 07: Điều khách hàng quan tâm</li>
                <li>• Section 08: Kiến thức Skincare</li>
                <li>• Section 09: FAQ Accordion</li>
                <li>• Section 10: Lead Form Tư vấn da</li>
                <li>• Section 11: CTA cuối trang</li>
              </ul>
            </div>

            <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
              <span className="text-xs font-mono font-bold text-[#1F3D2B]">2. VỀ VEDERA (About Us)</span>
              <ul className="text-xs text-[#526155] space-y-1.5 pl-3 border-l-2 border-[#87A98D]">
                <li>• Hero triết lý minh bạch</li>
                <li>• Brand Story & Nguồn gốc ý niệm</li>
                <li>• Sứ mệnh & Tầm nhìn</li>
                <li>• 5 Giá trị cốt lõi</li>
                <li>• Cam kết kiểm chứng (cGMP, Vegan)</li>
                <li>• Quy trình sản xuất an toàn</li>
              </ul>
            </div>

            <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
              <span className="text-xs font-mono font-bold text-[#1F3D2B]">3. CHI TIẾT SẢN PHẨM (PDP)</span>
              <ul className="text-xs text-[#526155] space-y-1.5 pl-3 border-l-2 border-[#87A98D]">
                <li>• Gallery hình ảnh & chai hổ phách</li>
                <li>• Module mua hàng & Giá niêm yết</li>
                <li>• Tra cứu INCI minh bạch từng chất</li>
                <li>• Hướng dẫn Patch test 48h</li>
                <li>• Kết hợp Routine Sáng/Tối</li>
                <li>• Điều hướng Shopee / TikTok Shop</li>
              </ul>
            </div>

            <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
              <span className="text-xs font-mono font-bold text-[#1F3D2B]">4. HƯỚNG DẪN & ROUTINE</span>
              <ul className="text-xs text-[#526155] space-y-1.5 pl-3 border-l-2 border-[#87A98D]">
                <li>• Cẩm nang Patch Test 4 bước</li>
                <li>• Checker tương thích hoạt chất (BHA, Retinol, HA, Niacinamide)</li>
                <li>• Lịch trình 14 ngày làm quen da</li>
                <li>• Xử lý khi có phản ứng bất thường</li>
              </ul>
            </div>

            <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
              <span className="text-xs font-mono font-bold text-[#1F3D2B]">5. BLOG KIẾN THỨC</span>
              <ul className="text-xs text-[#526155] space-y-1.5 pl-3 border-l-2 border-[#87A98D]">
                <li>• Bộ lọc danh mục (6 chủ đề)</li>
                <li>• Bài viết kiểm tra skincare mới</li>
                <li>• Bài viết đưa serum vào routine</li>
                <li>• Bài viết hiểu lầm về Vitamin C</li>
                <li>• Reader popup xem trọn vẹn</li>
              </ul>
            </div>

            <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
              <span className="text-xs font-mono font-bold text-[#1F3D2B]">6. LIÊN HỆ & TƯ VẤN</span>
              <ul className="text-xs text-[#526155] space-y-1.5 pl-3 border-l-2 border-[#87A98D]">
                <li>• Form đăng ký tư vấn da 1-1</li>
                <li>• Kênh liên hệ chính thức (Email, Hotline)</li>
                <li>• Chính sách bảo mật & đổi trả</li>
                <li>• Kênh mạng xã hội TikTok / Fanpage</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: UX Flow */}
      {activeTab === 'uxflow' && (
        <div className="bg-white rounded-3xl border border-[#E8E4DF] p-6 sm:p-10 shadow-xs space-y-8">
          <div className="space-y-1">
            <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-[#1F3D2B]">
              D & E. CTA MATRIX & CUSTOMER JOURNEY (UX FLOW)
            </h2>
            <p className="text-xs sm:text-sm text-[#526155]">
              Mô hình chuyển đổi nhẹ nhàng (Soft-sell Conversion), giảm áp lực mua sắm, tăng cường sự tin tưởng:
            </p>
          </div>

          <div className="space-y-4">
            {UX_FLOW_SPEC.steps.map((st, i) => (
              <div key={i} className="p-4 sm:p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] flex flex-col sm:flex-row sm:items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-[#1F3D2B] text-white flex items-center justify-center font-bold text-sm shrink-0">
                  {i + 1}
                </div>
                <div className="flex-1 min-w-0 space-y-1">
                  <span className="font-semibold text-sm text-[#1F3D2B] block">
                    {st.stage}
                  </span>
                  <p className="text-xs text-[#87A98D] font-mono">
                    Điểm chạm: {st.channel}
                  </p>
                  <p className="text-xs sm:text-sm text-[#4A574E] leading-relaxed">
                    Hành động của khách hàng: {st.action}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Design System */}
      {activeTab === 'designSystem' && (
        <div className="bg-white rounded-3xl border border-[#E8E4DF] p-6 sm:p-10 shadow-xs space-y-8">
          <div className="space-y-1">
            <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-[#1F3D2B]">
              F. DESIGN SYSTEM & QUY CHUẨN THẨM MỸ (CLEAN BEAUTY)
            </h2>
            <p className="text-xs sm:text-sm text-[#526155]">
              Được thiết kế dựa trên quy tắc 60-30-10, Zero-Pill Discipline và bảng màu thiên nhiên hữu cơ:
            </p>
          </div>

          {/* Color Palette */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-[#1F3D2B]">
              1. Bảng màu quy chuẩn (Color Palette)
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {DESIGN_SYSTEM_SPEC.colors.map((c, i) => (
                <div key={i} className="p-4 rounded-xl border border-[#E8E4DF] bg-[#FAF8F5] space-y-2">
                  <div
                    className="w-full h-12 rounded-lg border border-black/10 shadow-2xs"
                    style={{ backgroundColor: c.hex }}
                  />
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="font-semibold text-[#1F3D2B]">{c.name}</span>
                    <span>{c.hex}</span>
                  </div>
                  <p className="text-[11px] text-[#5F6D62] leading-relaxed">
                    {c.purpose}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Typography */}
          <div className="space-y-3 pt-4 border-t border-[#E8E4DF]">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-[#1F3D2B]">
              2. Hệ thống phông chữ (Typography System)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-1.5">
                <span className="font-semibold text-[#1F3D2B] block">Tiêu đề Display / Hero (Editorial):</span>
                <p className="font-serif text-2xl text-[#1F3D2B]">Cormorant Garamond</p>
                <p className="text-[#5F6D62]">
                  Font serif tinh tế, tạo cảm giác thanh lịch, cao cấp và thuần khiết cho ngành mỹ phẩm.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-1.5">
                <span className="font-semibold text-[#1F3D2B] block">Nội dung thân bài (Body Text):</span>
                <p className="font-sans text-lg font-medium text-[#1F3D2B]">Plus Jakarta Sans</p>
                <p className="text-[#5F6D62]">
                  Font sans-serif hình học hiện đại, độ dễ đọc cao trên màn hình điện thoại của Gen Z.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Tech & Responsive */}
      {activeTab === 'tech' && (
        <div className="bg-white rounded-3xl border border-[#E8E4DF] p-6 sm:p-10 shadow-xs space-y-8">
          <div className="space-y-1">
            <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-[#1F3D2B]">
              G & H. QUY CHUẨN RESPONSIVE & ĐỀ XUẤT NỀN TẢNG KỸ THUẬT
            </h2>
            <p className="text-xs sm:text-sm text-[#526155]">
              Đánh giá ưu nhược điểm các công cụ triển khai phù hợp cho bài tập đại học hoặc vận hành thương mại:
            </p>
          </div>

          {/* Responsive specs */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-[#1F3D2B]">
              Quy chuẩn hiển thị Responsive:
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-2">
                <span className="font-semibold text-[#1F3D2B] block">Desktop (1440px):</span>
                <p className="text-[#5F6D62] leading-relaxed">
                  Bố cục 12 cột, split-screen cho Hero và PDP, hiển thị menu ngang đầy đủ 7 mục, khoảng trắng thoáng đãng py-20.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-2">
                <span className="font-semibold text-[#1F3D2B] block">Tablet (768px – 1024px):</span>
                <p className="text-[#5F6D62] leading-relaxed">
                  Grid 2 cột cho các thẻ tính năng, menu thu gọn thông minh, hình ảnh sản phẩm căn chỉnh cân đối.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-2">
                <span className="font-semibold text-[#1F3D2B] block">Mobile (375px – 430px):</span>
                <p className="text-[#5F6D62] leading-relaxed">
                  Bố cục 1 cột, menu dạng Drawer trượt, nút CTA sticky tối giản dưới 15% chiều cao màn hình, touch target $\ge$ 44px.
                </p>
              </div>
            </div>
          </div>

          {/* Platforms recommendations */}
          <div className="space-y-4 pt-4 border-t border-[#E8E4DF]">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-[#1F3D2B]">
              So sánh các nền tảng kỹ thuật triển khai:
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {TECHNICAL_RECOMMENDATIONS.map((t, idx) => (
                <div key={idx} className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-semibold text-sm text-[#1F3D2B]">{t.platform}</h4>
                  </div>
                  <span className="text-[11px] text-[#87A98D] font-medium block">
                    {t.suitability}
                  </span>
                  <div className="text-xs text-[#526155] space-y-1 pt-1">
                    <p><strong>Ưu điểm:</strong> {t.pros}</p>
                    <p><strong>Hạn chế:</strong> {t.cons}</p>
                    {t.note && (
                      <p className="text-[#1F3D2B] font-medium bg-[#EDF3EE] p-2 rounded-lg mt-1">
                        ★ {t.note}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
