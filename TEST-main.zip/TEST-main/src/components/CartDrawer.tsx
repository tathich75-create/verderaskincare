import React, { useState } from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, CheckCircle2, ShieldAlert, Sparkles, ExternalLink } from 'lucide-react';
import { VEDERA_CORE_PRODUCT } from '../data/vederaContent';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  quantity: number;
  onUpdateQuantity: (qty: number) => void;
  onOpenConsultation: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  quantity,
  onUpdateQuantity,
  onOpenConsultation,
}) => {
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'bank'>('cod');
  const [orderId, setOrderId] = useState('');

  if (!isOpen) return null;

  const itemPrice = VEDERA_CORE_PRODUCT.price;
  const subtotal = itemPrice * quantity;
  const freeShippingThreshold = 300000;
  const shippingFee = subtotal >= freeShippingThreshold || quantity === 0 ? 0 : 25000;
  const grandTotal = subtotal + shippingFee;

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone || !customerAddress) {
      alert('Vui lòng nhập đầy đủ họ tên, số điện thoại và địa chỉ giao hàng.');
      return;
    }
    const generatedId = 'VED-' + Math.floor(100000 + Math.random() * 900000);
    setOrderId(generatedId);
    setCheckoutStep('success');
  };

  const handleReset = () => {
    onUpdateQuantity(0);
    setCheckoutStep('cart');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/40 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-[#FAF8F5] h-full shadow-2xl flex flex-col border-l border-[#E8E4DF]">
        {/* Header */}
        <div className="p-5 border-b border-[#E8E4DF] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#1F3D2B]" />
            <h3 className="font-serif text-xl font-semibold text-[#1F3D2B]">
              {checkoutStep === 'success'
                ? 'Đặt Hàng Thành Công'
                : checkoutStep === 'checkout'
                ? 'Thông Tin Giao Hàng'
                : 'Túi Hàng Của Bạn'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#5F6D62] hover:text-[#1F3D2B] rounded-lg transition-colors cursor-pointer"
            aria-label="Đóng túi hàng"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {checkoutStep === 'success' ? (
            <div className="text-center py-8 space-y-4">
              <div className="w-16 h-16 bg-[#EDF3EE] text-[#1F3D2B] rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <h4 className="font-serif text-2xl font-semibold text-[#1F3D2B]">
                Cảm ơn bạn đã lựa chọn Vedera!
              </h4>
              <p className="text-xs text-[#68776B] font-mono">
                Mã đơn hàng: <strong className="text-[#1F3D2B]">{orderId}</strong>
              </p>
              <div className="bg-white p-4 rounded-xl border border-[#E8E4DF] text-left text-xs space-y-2">
                <div className="flex justify-between">
                  <span className="text-[#68776B]">Khách hàng:</span>
                  <span className="font-medium text-[#1F3D2B]">{customerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#68776B]">Số điện thoại:</span>
                  <span className="font-medium text-[#1F3D2B]">{customerPhone}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#68776B]">Địa chỉ:</span>
                  <span className="font-medium text-[#1F3D2B] text-right truncate max-w-[200px]">
                    {customerAddress}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#68776B]">Phương thức:</span>
                  <span className="font-medium text-[#1F3D2B]">
                    {paymentMethod === 'cod' ? 'Thanh toán khi nhận hàng (COD)' : 'Chuyển khoản ngân hàng'}
                  </span>
                </div>
                <div className="border-t border-[#E8E4DF] pt-2 flex justify-between font-semibold text-sm">
                  <span>Tổng tiền:</span>
                  <span className="text-[#1F3D2B]">{grandTotal.toLocaleString('vi-VN')}₫</span>
                </div>
              </div>

              <div className="bg-[#EDF3EE] p-3.5 rounded-xl text-left text-xs text-[#2A4633] space-y-1">
                <p className="font-medium flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#1F3D2B]" />
                  <span>Quyền lợi đồng hành cùng làn da bạn:</span>
                </p>
                <p className="leading-relaxed">
                  Đơn hàng luôn được gửi kèm cẩm nang hướng dẫn Patch Test và bảng theo dõi 14 ngày làm quen da. Chuyên viên Vedera sẽ nhắn tin hỗ trợ khi bạn nhận hàng.
                </p>
              </div>

              <button
                onClick={handleReset}
                className="w-full py-3 bg-[#1F3D2B] text-white rounded-xl text-sm font-semibold hover:bg-[#162E20] transition-colors cursor-pointer"
              >
                Tiếp tục khám phá website
              </button>
            </div>
          ) : checkoutStep === 'checkout' ? (
            <form onSubmit={handlePlaceOrder} className="space-y-4">
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-[#444D46] mb-1">
                    Họ và tên người nhận *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ví dụ: Nguyễn Minh Anh"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#444D46] mb-1">
                    Số điện thoại nhận hàng *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="09xxxxxxxx"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#444D46] mb-1">
                    Địa chỉ nhận hàng chi tiết *
                  </label>
                  <textarea
                    rows={2}
                    required
                    placeholder="Số nhà, tên đường, phường/xã, quận/huyện, tỉnh/thành"
                    value={customerAddress}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    className="w-full text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#444D46] mb-1.5">
                    Hình thức thanh toán
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('cod')}
                      className={`p-2.5 text-xs text-left rounded-lg border transition-all ${
                        paymentMethod === 'cod'
                          ? 'border-[#1F3D2B] bg-[#EDF3EE] font-medium text-[#1F3D2B]'
                          : 'border-[#E8E4DF] bg-white text-[#5F6D62]'
                      }`}
                    >
                      Thanh toán khi nhận hàng (COD)
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('bank')}
                      className={`p-2.5 text-xs text-left rounded-lg border transition-all ${
                        paymentMethod === 'bank'
                          ? 'border-[#1F3D2B] bg-[#EDF3EE] font-medium text-[#1F3D2B]'
                          : 'border-[#E8E4DF] bg-white text-[#5F6D62]'
                      }`}
                    >
                      Chuyển khoản trước (Miễn phí)
                    </button>
                  </div>
                </div>
              </div>

              {/* Order Summary box */}
              <div className="bg-white p-3.5 rounded-xl border border-[#E8E4DF] text-xs space-y-1.5">
                <div className="flex justify-between text-[#5F6D62]">
                  <span>{VEDERA_CORE_PRODUCT.name} (x{quantity})</span>
                  <span className="tabular-nums font-medium text-[#2C332D]">{subtotal.toLocaleString('vi-VN')}₫</span>
                </div>
                <div className="flex justify-between text-[#5F6D62]">
                  <span>Phí vận chuyển:</span>
                  <span className="tabular-nums font-medium text-[#2C332D]">
                    {shippingFee === 0 ? 'Miễn phí' : `${shippingFee.toLocaleString('vi-VN')}₫`}
                  </span>
                </div>
                <div className="border-t border-[#E8E4DF] pt-1.5 flex justify-between text-sm font-semibold text-[#1F3D2B]">
                  <span>Tổng thanh toán:</span>
                  <span className="tabular-nums">{grandTotal.toLocaleString('vi-VN')}₫</span>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setCheckoutStep('cart')}
                  className="w-1/3 py-2.5 border border-[#CBD5CD] text-xs font-medium rounded-xl hover:bg-[#EAE5DE] text-[#444D46] transition-colors"
                >
                  Quay lại
                </button>
                <button
                  type="submit"
                  className="w-2/3 py-2.5 bg-[#1F3D2B] text-white text-xs font-semibold rounded-xl hover:bg-[#162E20] transition-colors"
                >
                  Xác nhận đặt hàng
                </button>
              </div>
            </form>
          ) : (
            /* Cart view */
            <>
              {quantity === 0 ? (
                <div className="text-center py-12 space-y-4">
                  <div className="w-14 h-14 bg-[#EDF3EE] rounded-full flex items-center justify-center mx-auto text-[#1F3D2B]">
                    <ShoppingBag className="w-7 h-7" />
                  </div>
                  <div>
                    <h4 className="font-serif text-lg font-semibold text-[#1F3D2B]">
                      Túi hàng của bạn đang trống
                    </h4>
                    <p className="text-xs text-[#68776B] mt-1 max-w-xs mx-auto">
                      Hãy tìm hiểu kỹ thông tin về Serum Vitamin C và hướng dẫn test da trước khi thêm vào routine nhé.
                    </p>
                  </div>
                  <button
                    onClick={() => onUpdateQuantity(1)}
                    className="px-5 py-2.5 bg-[#1F3D2B] text-white text-xs font-semibold rounded-full hover:bg-[#162E20] transition-colors cursor-pointer"
                  >
                    Thử nghiệm 1 chai Serum Vitamin C 30ml
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Cart Item Card */}
                  <div className="bg-white p-3.5 rounded-xl border border-[#E8E4DF] flex gap-3.5">
                    <img
                      src={VEDERA_CORE_PRODUCT.heroImage}
                      alt={VEDERA_CORE_PRODUCT.name}
                      referrerPolicy="no-referrer"
                      className="w-20 h-20 object-cover rounded-lg bg-[#FAF8F5]"
                    />
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div>
                        <span className="text-[11px] uppercase tracking-wider text-[#68776B] block">
                          Vedera Clean Beauty
                        </span>
                        <h4 className="text-sm font-semibold text-[#1F3D2B] truncate">
                          {VEDERA_CORE_PRODUCT.name}
                        </h4>
                        <span className="text-xs text-[#68776B] block">
                          Dung tích: {VEDERA_CORE_PRODUCT.capacity}
                        </span>
                      </div>

                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center border border-[#CBD5CD] rounded-md overflow-hidden bg-[#FAF8F5]">
                          <button
                            onClick={() => onUpdateQuantity(Math.max(0, quantity - 1))}
                            className="px-2 py-0.5 text-xs text-[#444D46] hover:bg-[#EAE5DE] transition-colors cursor-pointer"
                          >
                            -
                          </button>
                          <span className="px-2.5 py-0.5 text-xs font-medium tabular-nums text-[#1F3D2B]">
                            {quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(quantity + 1)}
                            className="px-2 py-0.5 text-xs text-[#444D46] hover:bg-[#EAE5DE] transition-colors cursor-pointer"
                          >
                            +
                          </button>
                        </div>

                        <div className="text-right">
                          <span className="text-sm font-semibold text-[#1F3D2B] tabular-nums">
                            {(itemPrice * quantity).toLocaleString('vi-VN')}₫
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Free shipping progress indicator */}
                  <div className="bg-[#EDF3EE] p-3 rounded-xl border border-[#CBD5CD] text-xs">
                    {subtotal >= freeShippingThreshold ? (
                      <p className="text-[#1F3D2B] font-medium flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-[#1F3D2B]" />
                        <span>Bạn đã đủ điều kiện nhận <strong>Miễn phí vận chuyển toàn quốc</strong>!</span>
                      </p>
                    ) : (
                      <div>
                        <p className="text-[#2C4A34]">
                          Thêm <strong>{(freeShippingThreshold - subtotal).toLocaleString('vi-VN')}₫</strong> để nhận Miễn phí vận chuyển.
                        </p>
                        <div className="w-full bg-[#CBD5CD] h-1.5 rounded-full mt-1.5 overflow-hidden">
                          <div
                            className="bg-[#1F3D2B] h-full rounded-full transition-all duration-300"
                            style={{ width: `${Math.min(100, (subtotal / freeShippingThreshold) * 100)}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Pre-Sell Platforms redirection */}
                  <div className="bg-white p-3 rounded-xl border border-[#E8E4DF] space-y-2">
                    <span className="text-xs text-[#68776B] block">
                      Hoặc đặt qua các sàn TMĐT chính hãng (Shopee / TikTok Shop):
                    </span>
                    <div className="grid grid-cols-2 gap-2">
                      <a
                        href="#"
                        onClick={(e) => {
                          e.preventDefault();
                          alert('Chuyển hướng đến Shopee Mall chính thức: [Điền link gian hàng thực tế của Vedera]');
                        }}
                        className="flex items-center justify-center gap-1.5 p-2 rounded-lg border border-[#CBD5CD] text-xs font-medium text-[#EE4D2D] hover:bg-[#FFF5F2] transition-colors"
                      >
                        <span>Shopee Mall</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                      <a
                        href="#"
                        onClick={(e) => {
                          e.preventDefault();
                          alert('Chuyển hướng đến TikTok Shop chính thức: [Điền link TikTok Shop thực tế của Vedera]');
                        }}
                        className="flex items-center justify-center gap-1.5 p-2 rounded-lg border border-[#CBD5CD] text-xs font-medium text-[#111111] hover:bg-[#F4F4F4] transition-colors"
                      >
                        <span>TikTok Shop</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>

                  {/* Gentle reminder about Patch Test */}
                  <div className="p-3 bg-[#FAF4ED] rounded-xl border border-[#E9DACB] flex items-start gap-2.5 text-xs text-[#6D4C2F]">
                    <ShieldAlert className="w-4 h-4 shrink-0 text-[#B87333] mt-0.5" />
                    <div>
                      <p className="font-medium">Lưu ý trước khi đặt hàng:</p>
                      <p className="text-[11px] mt-0.5 leading-relaxed">
                        Mỗi hộp sản phẩm gửi đi đều tặng kèm mẫu thử nhỏ và cẩm nang Patch Test. Nếu bạn chưa chắc chắn về độ tương thích của da, hãy bấm <strong>Nhận tư vấn routine</strong> trước khi quyết định mua.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer actions */}
        {checkoutStep === 'cart' && quantity > 0 && (
          <div className="p-4 border-t border-[#E8E4DF] bg-white space-y-3">
            <div className="space-y-1 text-xs">
              <div className="flex justify-between text-[#68776B]">
                <span>Tạm tính:</span>
                <span className="font-medium text-[#2C332D] tabular-nums">{subtotal.toLocaleString('vi-VN')}₫</span>
              </div>
              <div className="flex justify-between text-[#68776B]">
                <span>Vận chuyển:</span>
                <span className="font-medium text-[#2C332D] tabular-nums">
                  {shippingFee === 0 ? 'Miễn phí' : `${shippingFee.toLocaleString('vi-VN')}₫`}
                </span>
              </div>
              <div className="flex justify-between text-base font-semibold text-[#1F3D2B] pt-1 border-t border-[#E8E4DF]">
                <span>Tổng cộng:</span>
                <span className="tabular-nums">{grandTotal.toLocaleString('vi-VN')}₫</span>
              </div>
            </div>

            <button
              onClick={() => setCheckoutStep('checkout')}
              className="w-full py-3 bg-[#1F3D2B] text-white text-sm font-semibold rounded-xl hover:bg-[#162E20] transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Tiến hành đặt hàng trực tiếp</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
