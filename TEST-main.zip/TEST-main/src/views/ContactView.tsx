import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle2, Sparkles, MessageSquare } from 'lucide-react';

export const ContactView: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    topic: 'Tư vấn da nhạy cảm & Routine',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.phone) {
      alert('Vui lòng điền đầy đủ các thông tin bắt buộc.');
      return;
    }
    setSubmitted(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
      {/* Header */}
      <div className="max-w-3xl mx-auto text-center space-y-4">
        <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
          Kênh Kết Nối
        </span>
        <h1 className="font-serif text-4xl sm:text-5xl font-semibold text-[#1F3D2B]">
          Liên hệ & Đăng ký tư vấn
        </h1>
        <p className="text-sm sm:text-base text-[#526155] leading-relaxed">
          Vedera luôn sẵn sàng lắng nghe mọi băn khoăn về làn da và tiếp nhận đóng góp để hoàn thiện sản phẩm.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Left: Contact Info & Channels */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-[#E8E4DF] space-y-6 shadow-xs">
            <h3 className="font-serif text-2xl font-semibold text-[#1F3D2B]">
              Thông tin liên hệ chính thức
            </h3>

            <div className="space-y-4 text-sm text-[#444D46]">
              <div className="flex items-start gap-3.5">
                <div className="p-2 bg-[#EDF3EE] text-[#1F3D2B] rounded-xl shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs text-[#87A98D] block font-medium">Hộp thư điện tử:</span>
                  <span className="font-medium text-[#1F3D2B]">hello@vederaskincare.vn</span>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="p-2 bg-[#EDF3EE] text-[#1F3D2B] rounded-xl shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs text-[#87A98D] block font-medium">Hotline tư vấn da:</span>
                  <span className="font-medium text-[#1F3D2B]">1900 xxxx [Placeholder]</span>
                  <span className="text-xs text-[#68776B] block">Hỗ trợ từ 8:30 - 20:00 (Thứ 2 đến Thứ 7)</span>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="p-2 bg-[#EDF3EE] text-[#1F3D2B] rounded-xl shrink-0">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs text-[#87A98D] block font-medium">Kênh cộng đồng:</span>
                  <span className="text-xs text-[#1F3D2B] block">Facebook: [Điền Fanpage Vedera Skincare]</span>
                  <span className="text-xs text-[#1F3D2B] block">TikTok: [Điền kênh TikTok @vedera.vn]</span>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="p-2 bg-[#EDF3EE] text-[#1F3D2B] rounded-xl shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs text-[#87A98D] block font-medium">Văn phòng / Đơn vị quản lý:</span>
                  <span className="text-xs text-[#526155]">
                    [Điền địa chỉ đăng ký kinh doanh hoặc văn phòng đại diện thực tế]
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive placeholder map */}
          <div className="bg-[#EAE5DE] p-6 rounded-3xl border border-[#DCD5CB] text-center space-y-2">
            <span className="text-xs uppercase tracking-wider text-[#68776B] block font-semibold">
              Khu Vực Văn Phòng
            </span>
            <p className="text-xs text-[#526155]">
              [Vị trí bản đồ sẽ hiển thị khi có địa điểm văn phòng hoặc showroom thực tế]
            </p>
          </div>
        </div>

        {/* Right: Contact Form */}
        <div className="lg:col-span-7">
          <div className="bg-white p-6 sm:p-10 rounded-3xl border border-[#E8E4DF] shadow-xs">
            {submitted ? (
              <div className="text-center py-10 space-y-4">
                <div className="w-16 h-16 bg-[#EDF3EE] text-[#1F3D2B] rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-9 h-9" />
                </div>
                <h3 className="font-serif text-3xl font-semibold text-[#1F3D2B]">
                  Vedera đã nhận được tin nhắn!
                </h3>
                <p className="text-sm text-[#526155] max-w-md mx-auto leading-relaxed">
                  Cảm ơn <strong>{formData.name}</strong> đã gửi yêu cầu. Chúng tôi sẽ phản hồi lại bạn qua email <strong>{formData.email}</strong> trong thời gian sớm nhất.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="px-6 py-2.5 bg-[#1F3D2B] text-white text-xs font-semibold rounded-full hover:bg-[#162E20] transition-colors cursor-pointer"
                >
                  Gửi thêm nội dung khác
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-1">
                  <h3 className="font-serif text-2xl font-semibold text-[#1F3D2B]">
                    Gửi yêu cầu tư vấn / Liên hệ
                  </h3>
                  <p className="text-xs text-[#68776B]">
                    Điền các thông tin dưới đây để nhận phản hồi từ đội ngũ Vedera:
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#444D46] mb-1">
                      Họ và tên *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ví dụ: Hoàng Minh Châu"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-[#FAF8F5] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#444D46] mb-1">
                      Số điện thoại *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="09xxxxxxxx"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-[#FAF8F5] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#444D46] mb-1">
                    Địa chỉ email *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="name@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-[#FAF8F5] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#444D46] mb-1">
                    Chủ đề cần hỗ trợ
                  </label>
                  <select
                    value={formData.topic}
                    onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                    className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-[#FAF8F5] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                  >
                    <option value="Tư vấn da nhạy cảm & Routine">Tư vấn da nhạy cảm & Routine</option>
                    <option value="Hỏi về bảng thành phần INCI">Hỏi về bảng thành phần INCI</option>
                    <option value="Chính sách bảo hành & Đổi trả">Chính sách bảo hành & Đổi trả</option>
                    <option value="Hợp tác truyền thông / Đại sứ xanh">Hợp tác truyền thông / Đại sứ xanh</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#444D46] mb-1">
                    Nội dung chi tiết
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Mô tả chi tiết câu hỏi hoặc tình trạng làn da của bạn..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-[#FAF8F5] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full sm:w-auto px-8 py-3 bg-[#1F3D2B] text-white text-xs sm:text-sm font-semibold rounded-full hover:bg-[#162E20] transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                  >
                    <Send className="w-4 h-4" />
                    <span>Gửi yêu cầu tư vấn</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
