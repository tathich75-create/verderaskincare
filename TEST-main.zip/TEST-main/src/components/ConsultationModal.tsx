import React, { useState } from 'react';
import { X, CheckCircle2, Sparkles, Send, ShieldCheck, Heart } from 'lucide-react';

interface ConsultationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ConsultationModal: React.FC<ConsultationModalProps> = ({ isOpen, onClose }) => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    skinType: 'Da nhạy cảm, dễ kích ứng',
    skinGoal: 'Làm mờ thâm mụn & sáng đều màu dịu nhẹ',
    currentProducts: '',
    message: '',
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.email || !formData.phone) {
      alert('Vui lòng điền họ tên, email và số điện thoại để Vedera liên hệ tư vấn.');
      return;
    }
    setSubmitted(true);
  };

  const handleReset = () => {
    setSubmitted(false);
    setFormData({
      fullName: '',
      email: '',
      phone: '',
      skinType: 'Da nhạy cảm, dễ kích ứng',
      skinGoal: 'Làm mờ thâm mụn & sáng đều màu dịu nhẹ',
      currentProducts: '',
      message: '',
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-[#FAF8F5] rounded-2xl shadow-2xl border border-[#E8E4DF] overflow-hidden">
        {/* Modal Top */}
        <div className="p-6 border-b border-[#E8E4DF] bg-white flex items-center justify-between">
          <div className="space-y-0.5">
            <span className="text-xs uppercase tracking-wider text-[#68776B] font-medium flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#1F3D2B]" />
              <span>Chăm Da Có Cơ Sở · Tư Vấn Miễn Phí 1-1</span>
            </span>
            <h3 className="font-serif text-2xl font-semibold text-[#1F3D2B]">
              Đăng Ký Tư Vấn Routine
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#5F6D62] hover:text-[#1F3D2B] rounded-lg transition-colors cursor-pointer"
            aria-label="Đóng form"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6">
          {submitted ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 bg-[#EDF3EE] text-[#1F3D2B] rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <div className="space-y-2">
                <h4 className="font-serif text-2xl font-semibold text-[#1F3D2B]">
                  Vedera đã nhận được thông tin!
                </h4>
                <p className="text-sm text-[#444D46] max-w-md mx-auto leading-relaxed">
                  Cảm ơn <strong>{formData.fullName}</strong> đã quan tâm đến Vedera Skincare. Đội ngũ chuyên viên sẽ rà soát routine hiện tại của bạn và gửi phản hồi qua email <strong>{formData.email}</strong> hoặc Zalo trong vòng 24 giờ.
                </p>
              </div>

              {/* Instant Routine Check Diagnostic Card */}
              <div className="p-4 bg-white rounded-xl border border-[#E8E4DF] text-left text-xs space-y-2">
                <p className="font-semibold text-[#1F3D2B] flex items-center gap-1.5 text-sm">
                  <ShieldCheck className="w-4 h-4 text-[#87A98D]" />
                  <span>Ghi nhận hồ sơ làn da của bạn:</span>
                </p>
                <div className="grid grid-cols-2 gap-2 text-[#5F6D62]">
                  <div>
                    <span className="text-[11px] block text-[#87A98D]">Tình trạng da:</span>
                    <span className="font-medium text-[#2C332D]">{formData.skinType}</span>
                  </div>
                  <div>
                    <span className="text-[11px] block text-[#87A98D]">Mục tiêu ưu tiên:</span>
                    <span className="font-medium text-[#2C332D]">{formData.skinGoal}</span>
                  </div>
                </div>
                <div className="p-3 bg-[#EDF3EE] rounded-lg text-[#1F3D2B] text-[11px] leading-relaxed">
                  <strong>Khuyến nghị sơ bộ:</strong> Với loại da nhạy cảm muốn làm quen Vitamin C, Vedera khuyến nghị bắt đầu với nồng độ dẫn xuất E-AA dịu nhẹ, thực hiện patch test 48h và kết hợp kem phục hồi có B5 trước khi dùng hàng ngày.
                </div>
              </div>

              <button
                onClick={handleReset}
                className="w-full py-3 bg-[#1F3D2B] text-white rounded-xl text-sm font-semibold hover:bg-[#162E20] transition-colors cursor-pointer"
              >
                Hoàn tất & Đóng cửa sổ
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="text-xs text-[#5F6D62] pb-1">
                "Chưa biết sản phẩm nào phù hợp với routine của bạn? Để lại một vài thông tin để Vedera hỗ trợ bạn tìm hiểu sản phẩm phù hợp hơn."
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-medium text-[#444D46] mb-1">
                    Họ và tên *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ví dụ: Lê Thảo My"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#444D46] mb-1">
                    Số điện thoại / Zalo *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="09xxxxxxxx"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#444D46] mb-1">
                  Email nhận tư vấn *
                </label>
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-medium text-[#444D46] mb-1">
                    Tình trạng da hiện tại
                  </label>
                  <select
                    value={formData.skinType}
                    onChange={(e) => setFormData({ ...formData, skinType: e.target.value })}
                    className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                  >
                    <option value="Da nhạy cảm, dễ kích ứng">Da nhạy cảm, dễ kích ứng</option>
                    <option value="Da khô hoặc hỗn hợp thiên khô">Da khô hoặc hỗn hợp thiên khô</option>
                    <option value="Da dầu hoặc hỗn hợp thiên dầu">Da dầu hoặc hỗn hợp thiên dầu</option>
                    <option value="Da đang có mụn viêm nhẹ">Da đang có mụn viêm nhẹ</option>
                    <option value="Da xỉn màu, nhiều vết thâm">Da xỉn màu, nhiều vết thâm</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#444D46] mb-1">
                    Mục tiêu chăm sóc da
                  </label>
                  <select
                    value={formData.skinGoal}
                    onChange={(e) => setFormData({ ...formData, skinGoal: e.target.value })}
                    className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-[#CBD5CD] bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                  >
                    <option value="Làm mờ thâm mụn & sáng đều màu dịu nhẹ">Làm mờ thâm mụn & sáng dịu nhẹ</option>
                    <option value="Chống oxy hóa & bảo vệ trước ánh nắng">Chống oxy hóa & bảo vệ da</option>
                    <option value="Củng cố hàng rào màng ẩm, giảm khô rát">Củng cố hàng rào màng ẩm</option>
                    <option value="Tối giản chu trình skincare lành tính">Tối giản chu trình lành tính</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#444D46] mb-1">
                  Sản phẩm đang sử dụng (sữa rửa mặt, kem chống nắng, serum...)
                </label>
                <input
                  type="text"
                  placeholder="Ví dụ: Đang dùng sữa rửa mặt tạo bọt dịu nhẹ, kem dưỡng ẩm B5..."
                  value={formData.currentProducts}
                  onChange={(e) => setFormData({ ...formData, currentProducts: e.target.value })}
                  className="w-full text-xs sm:text-sm px-3.5 py-2 rounded-lg border border-[#CBD5CD] bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#444D46] mb-1">
                  Nội dung cần tư vấn thêm
                </label>
                <textarea
                  rows={2}
                  placeholder="Chia sẻ thêm về tiền sử dị ứng hoặc những lo lắng của bạn khi thử sản phẩm mới..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full text-xs sm:text-sm px-3.5 py-2 rounded-lg border border-[#CBD5CD] bg-white focus:outline-none focus:ring-2 focus:ring-[#1F3D2B]/30"
                />
              </div>

              <div className="flex items-center gap-2 text-[11px] text-[#68776B] pt-1">
                <Heart className="w-3.5 h-3.5 text-[#87A98D] shrink-0" />
                <span>Cam kết bảo mật thông tin cá nhân. Vedera không chia sẻ dữ liệu cho bên thứ ba.</span>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#1F3D2B] text-white text-sm font-semibold rounded-xl hover:bg-[#162E20] transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              >
                <Send className="w-4 h-4" />
                <span>Đăng ký tư vấn</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
