import React from 'react';
import { Leaf, ShieldCheck, HeartHandshake, Eye, Sparkles, ArrowRight, CheckCircle2 } from 'lucide-react';
import { VEDERA_CORE_VALUES } from '../data/vederaContent';

interface AboutViewProps {
  onSelectTab: (tab: string) => void;
  onOpenConsultation: () => void;
}

export const AboutView: React.FC<AboutViewProps> = ({ onSelectTab, onOpenConsultation }) => {
  return (
    <div className="space-y-16 sm:space-y-24 py-8 sm:py-12">
      {/* 1. Hero */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <div className="flex items-center justify-center gap-2 text-xs font-medium text-[#4D6553]">
            <span>Về Vedera Skincare</span>
            <span aria-hidden="true">·</span>
            <span>Triết Lý Clean Beauty</span>
          </div>

          <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-semibold text-[#1F3D2B] leading-[1.15] text-balance">
            Skincare minh bạch bắt đầu từ những điều rõ ràng.
          </h1>

          <p className="text-base sm:text-lg text-[#4A574E] leading-relaxed">
            Chúng tôi tin rằng làn da không cần những lời hứa hẹn thần thánh hóa. Làn da cần sự thấu hiểu, những hoạt chất lành tính đã được chứng minh và một bảng thành phần minh bạch 100%.
          </p>
        </div>
      </section>

      {/* 2. Brand Story & Visual */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          <div className="lg:col-span-6 rounded-3xl overflow-hidden bg-[#F0EBE1] border border-[#E8E4DF] shadow-sm">
            <img
              src="/src/assets/images/botanical_texture_leaves_1790145845639.jpg"
              alt="Botanical plant extracts on natural stone"
              referrerPolicy="no-referrer"
              className="w-full h-[400px] object-cover"
            />
          </div>

          <div className="lg:col-span-6 space-y-5">
            <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
              Khởi Nguồn Ý Niệm
            </span>

            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1F3D2B]">
              Câu chuyện hình thành Vedera
            </h2>

            <div className="space-y-4 text-sm text-[#4A574E] leading-relaxed">
              <p>
                Vedera được ấp ủ từ chính trải nghiệm của những bạn trẻ thế hệ Gen Z: sinh viên và những người vừa bước chân vào môi trường công sở. Khi bắt đầu quan tâm đến chăm sóc da, điều đón nhận chúng ta không phải là sự tự tin, mà là hàng ngàn video quảng cáo giật gân, những lời cam kết "trắng bật tông sau 3 ngày" và những lần da nổi mẩn vì bảng thành phần chứa đầy cồn khô hay hương liệu ẩn.
              </p>
              <p>
                Chúng tôi tự hỏi: <em>Tại sao việc chọn một lọ serum dưỡng da lành tính lại khó khăn và đầy rủi ro đến thế?</em>
              </p>
              <p>
                Vedera ra đời để trở thành lời giải cho câu hỏi đó: Một thương hiệu skincare thuần chay (Vegan), ưu tiên nguồn nguyên liệu thực vật hữu cơ, tuyệt đối nói không với thử nghiệm trên động vật và công khai 100% tên khoa học của từng chất trong chai sản phẩm.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Mission & Vision */}
      <section className="bg-[#F5F0E8]/60 py-16 border-y border-[#EAE3D9]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
            <div className="bg-white p-8 sm:p-10 rounded-3xl border border-[#E8E4DF] space-y-4 shadow-xs">
              <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
                Sứ Mệnh (Our Mission)
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl font-semibold text-[#1F3D2B]">
                Vedera muốn mang lại điều gì cho bạn?
              </h3>
              <p className="text-sm text-[#526155] leading-relaxed">
                Mang đến sự an tâm tuyệt đối trong từng lần thoa dưỡng. Giúp người có làn da nhạy cảm dễ kích ứng có thể tiếp cận với các hoạt chất chống oxy hóa hiệu quả mà không phải đánh đổi bằng cảm giác châm chích, đỏ rát hay tâm lý lo âu.
              </p>
            </div>

            <div className="bg-white p-8 sm:p-10 rounded-3xl border border-[#E8E4DF] space-y-4 shadow-xs">
              <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
                Tầm Nhìn (Our Vision)
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl font-semibold text-[#1F3D2B]">
                Chuẩn mực mới cho mỹ phẩm thế hệ trẻ
              </h3>
              <p className="text-sm text-[#526155] leading-relaxed">
                Trở thành biểu tượng của phong trào mỹ phẩm minh bạch tại Việt Nam. Nơi mọi sản phẩm bán ra đều đi kèm cẩm nang sử dụng có cơ sở khoa học, tôn trọng quyền được biết của người tiêu dùng và tôn trọng sự sống của muôn loài.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Brand Values */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
            5 Giá Trị Cốt Lõi
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1F3D2B]">
            Những nguyên tắc không bao giờ thỏa hiệp
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {VEDERA_CORE_VALUES.map((val) => (
            <div
              key={val.code}
              className="p-6 rounded-2xl bg-white border border-[#E8E4DF] space-y-3"
            >
              <span className="text-xs font-mono font-semibold text-[#87A98D] block">
                {val.code} / VEDERA ETHOS
              </span>
              <h3 className="font-semibold text-lg text-[#1F3D2B]">
                {val.title}
              </h3>
              <p className="text-xs sm:text-sm text-[#526155] leading-relaxed">
                {val.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Verifiable Commitments & Process */}
      <section className="bg-white py-16 border-y border-[#E8E4DF]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="max-w-3xl mx-auto text-center space-y-3">
            <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
              Kiểm Chứng Khách Quan
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1F3D2B]">
              Cam kết thực tế có thể kiểm tra
            </h2>
            <p className="text-sm text-[#526155]">
              Chúng tôi chỉ đưa ra các tuyên bố mà khách hàng có thể đối chiếu trực tiếp trên nhãn mác và dữ liệu công bố:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
              <CheckCircle2 className="w-5 h-5 text-[#87A98D]" />
              <h4 className="font-semibold text-base text-[#1F3D2B]">
                Quy chuẩn cGMP sản xuất
              </h4>
              <p className="text-xs text-[#526155] leading-relaxed">
                Gia công và đóng gói tại nhà máy đạt chuẩn Thực hành tốt sản xuất mỹ phẩm (cGMP-ASEAN) [Điền tên cơ sở đối tác sản xuất thực tế khi có thông tin].
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
              <CheckCircle2 className="w-5 h-5 text-[#87A98D]" />
              <h4 className="font-semibold text-base text-[#1F3D2B]">
                Chứng nhận thuần chay (Vegan)
              </h4>
              <p className="text-xs text-[#526155] leading-relaxed">
                [Điền tổ chức chứng nhận nếu có hoặc biên bản xác thực nguyên liệu thuần chay 100% từ nhà cung cấp chiết xuất hữu cơ].
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#FAF8F5] border border-[#E8E4DF] space-y-3">
              <CheckCircle2 className="w-5 h-5 text-[#87A98D]" />
              <h4 className="font-semibold text-base text-[#1F3D2B]">
                Số tiếp nhận công bố mỹ phẩm
              </h4>
              <p className="text-xs text-[#526155] leading-relaxed">
                Mỗi lô sản phẩm lưu hành đều có số tiếp nhận Phiếu công bố sản phẩm mỹ phẩm do cơ quan quản lý y tế cấp [Điền số công bố thực tế].
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. CTA Footer Section */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
        <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1F3D2B]">
          Sẵn sàng trải nghiệm tinh chất Vitamin C dịu lành?
        </h2>
        <p className="text-sm text-[#526155] max-w-lg mx-auto">
          Tìm hiểu chi tiết thành phần sản phẩm hoặc liên hệ đội ngũ chuyên viên để rà soát routine cùng bạn.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-4">
          <button
            onClick={() => onSelectTab('product')}
            className="px-8 py-3.5 bg-[#1F3D2B] text-white text-sm font-semibold rounded-full hover:bg-[#162E20] transition-colors cursor-pointer"
          >
            Khám phá sản phẩm
          </button>
          <button
            onClick={onOpenConsultation}
            className="px-8 py-3.5 bg-transparent border-1.5 border-[#1F3D2B] text-[#1F3D2B] text-sm font-semibold rounded-full hover:bg-[#EDF3EE] transition-colors cursor-pointer"
          >
            Đăng ký tư vấn da
          </button>
        </div>
      </section>
    </div>
  );
};
