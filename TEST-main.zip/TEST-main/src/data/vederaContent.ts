/**
 * Dữ liệu & Nội dung chính thức cho VEDERA SKINCARE
 * Tuân thủ nghiêm ngặt: MINH BẠCH - THUẦN CHAY - CHĂM DA CÓ CƠ SỞ
 * Không bịa số liệu, không cam kết y khoa tuyệt đối, sử dụng placeholder chuẩn mực.
 */

export interface ProductInfo {
  id: string;
  name: string;
  subtitle: string;
  capacity: string;
  price: number;
  originalPrice?: number;
  summary: string;
  heroImage: string;
  highlightPoints: string[];
  inciKeyIngredients: {
    name: string;
    scientificName: string;
    origin: string;
    purpose: string;
    safetyNote: string;
  }[];
  fullIngredientsList: string;
  usageInstructions: {
    stepNumber: string;
    title: string;
    description: string;
  }[];
  patchTestGuide: string[];
  whoIsThisFor: string[];
  whoShouldAvoid: string[];
  storageNotes: string[];
  eCommerceLinks: {
    shopee: string;
    tiktokShop: string;
  };
}

export const VEDERA_CORE_PRODUCT: ProductInfo = {
  id: 'vedera-vitamin-c-serum-30ml',
  name: 'Vedera Vitamin C Gentle Brightening Serum',
  subtitle: 'Tinh chất dưỡng sáng & củng cố hàng rào da thuần chay',
  capacity: '30ml (1.01 fl. oz.)',
  price: 285000,
  originalPrice: 320000,
  summary: 'Serum Vitamin C thế hệ mới (dẫn xuất E-AA) kết hợp chiết xuất rau má hữu cơ và Hyaluronic Acid đa tầng, định hướng làm đều màu da nhẹ nhàng, hạn chế tối đa cảm giác châm chích cho làn da nhạy cảm.',
  heroImage: '/src/assets/images/product_serum_30ml_1790145833338.jpg',
  highlightPoints: [
    'Dẫn xuất 3-O-Ethyl Ascorbic Acid (E-AA) bền vững với ánh sáng, ít oxy hóa ngả vàng.',
    'Bổ sung chiết xuất Centella Asiatica (Rau má hữu cơ) giúp làm dịu và giảm cảm giác đỏ rát.',
    'Công thức thuần chay (Vegan), không cồn khô, không paraben, không hương liệu nhân tạo tổng hợp.',
    'Không thử nghiệm trên động vật (Cruelty-Free).',
    'Độ pH dịu nhẹ 5.5 – 6.0 cân bằng sinh lý màng ẩm tự nhiên của da.'
  ],
  inciKeyIngredients: [
    {
      name: '3-O-Ethyl Ascorbic Acid (Dẫn xuất Vitamin C)',
      scientificName: '3-O-Ethyl Ascorbic Acid (E-AA)',
      origin: 'Tổng hợp công nghệ sinh học từ nguồn gốc thực vật',
      purpose: 'Hỗ trợ làm đều màu da, chống oxy hóa trước tác động môi trường mà không cần môi trường pH quá acid như L-AA thuần.',
      safetyNote: 'Độ kích ứng thấp hơn đáng kể so với L-Ascorbic Acid, phù hợp da mới làm quen với Vitamin C.'
    },
    {
      name: 'Chiết xuất Rau má Hữu cơ',
      scientificName: 'Centella Asiatica Leaf Extract',
      origin: 'Chiết xuất thảo mộc canh tác chuẩn hữu cơ',
      purpose: 'Làm dịu làn da mẫn cảm, hỗ trợ củng cố hàng rào bảo vệ tự nhiên và giữ ẩm.',
      safetyNote: 'Lành tính, thường được ứng dụng trong các giải pháp phục hồi da sau mụn.'
    },
    {
      name: 'Hyaluronic Acid đa phân tử',
      scientificName: 'Sodium Hyaluronate',
      origin: 'Lên men vi sinh tự nhiên',
      purpose: 'Cấp ẩm đa tầng từ bề mặt đến các lớp biểu bì, giúp da duy trì độ mềm mại, mọng nước.',
      safetyNote: 'Tương thích sinh học cao, không gây bít tắc lỗ chân lông.'
    },
    {
      name: 'Panthenol (Pro-Vitamin B5)',
      scientificName: 'D-Panthenol',
      origin: 'Nguồn gốc thực vật',
      purpose: 'Hỗ trợ giảm tình trạng khô ráp, giảm ngứa rát khi thời tiết giao mùa hoặc da tiếp xúc khói bụi.',
      safetyNote: 'Thành phần phục hồi kinh điển, an toàn cho da nhạy cảm.'
    },
    {
      name: 'Ferulic Acid thực vật',
      scientificName: 'Ferulic Acid',
      origin: 'Chiết xuất từ cám gạo hữu cơ',
      purpose: 'Đóng vai trò chất chống oxy hóa tự nhiên giúp ổn định dẫn xuất Vitamin C và kéo dài độ tươi mới của tinh chất.',
      safetyNote: 'Hỗ trợ bảo vệ tế bào da trước các gốc tự do hình thành từ tia UV.'
    }
  ],
  fullIngredientsList: 'Aqua (Nước tinh khiết), Butylene Glycol, 3-O-Ethyl Ascorbic Acid, Centella Asiatica Extract (Chiết xuất rau má hữu cơ), Glycerin, Sodium Hyaluronate, Panthenol (Vitamin B5), Ferulic Acid, Allantoin, Hydroxyethylcellulose, Disodium EDTA, Ethylhexylglycerin, Phenoxyethanol (dưới 0.5% bảo quản chuẩn an toàn mỹ phẩm).',
  usageInstructions: [
    {
      stepNumber: '01',
      title: 'Làm sạch & Cân bằng',
      description: 'Rửa mặt bằng sữa rửa mặt dịu nhẹ, cân bằng da bằng toner cấp ẩm không cồn.'
    },
    {
      stepNumber: '02',
      title: 'Thoa Serum Vedera',
      description: 'Lấy 3-4 giọt serum ra lòng bàn tay hoặc nhỏ trực tiếp lên má/trán. Vỗ nhẹ đều khắp mặt và cổ đến khi thẩm thấu hoàn toàn.'
    },
    {
      stepNumber: '03',
      title: 'Khóa ẩm & Chống nắng',
      description: 'Thoa kem dưỡng ẩm để khóa dưỡng chất. Nếu dùng ban ngày, BẮT BUỘC thoa kem chống nắng quang phổ rộng SPF 30 trở lên.'
    }
  ],
  patchTestGuide: [
    'Bước 1: Làm sạch một vùng da nhỏ ở mặt trong cổ tay hoặc góc xương quai hàm (khoảng 2x2 cm).',
    'Bước 2: Chấm 1 giọt serum Vedera lên vùng da này và để khô tự nhiên.',
    'Bước 3: Giữ nguyên trong 24 đến 48 giờ. Tránh chà xát hoặc để nước tẩy rửa dính vào.',
    'Bước 4: Quan sát phản ứng. Nếu không xuất hiện vết đỏ, ngứa ngáy hay nổi mẩn li ti, bạn có thể bắt đầu sử dụng trên mặt 2-3 lần/tuần.'
  ],
  whoIsThisFor: [
    'Làn da xỉn màu, không đều màu do thức khuya hoặc tiếp xúc ánh nắng.',
    'Da có vết thâm sau mụn cần hỗ trợ sáng dần theo chu kỳ tái tạo tự nhiên.',
    'Da nhạy cảm muốn bắt đầu routine chống oxy hóa với dẫn xuất Vitamin C êm dịu.',
    'Người tìm kiếm sản phẩm dưỡng da thuần chay, minh bạch bảng thành phần.'
  ],
  whoShouldAvoid: [
    'Da đang có vết thương hở, mụn viêm bọc mủ lan rộng hoặc viêm da dị ứng cấp tính.',
    'Người có tiền sử dị ứng với bất kỳ thành phần nào trong bảng INCI được công bố.'
  ],
  storageNotes: [
    'Bảo quản nơi khô ráo, thoáng mát, nhiệt độ dưới 28°C.',
    'Tránh ánh nắng mặt trời chiếu trực tiếp vào chai.',
    'Đậy kín nắp dropper sau mỗi lần lấy serum để tránh tiếp xúc không khí kéo dài.'
  ],
  eCommerceLinks: {
    shopee: '[Điền link gian hàng Shopee Mall chính thức]',
    tiktokShop: '[Điền link TikTok Shop chính thức]'
  }
};

export interface ArticleItem {
  id: string;
  title: string;
  category: string;
  date: string;
  readTime: string;
  summary: string;
  thumbnail: string;
  contentParagraphs: string[];
  keyTakeaways: string[];
}

export const ARTICLES_DATA: ArticleItem[] = [
  {
    id: '4-buoc-kiem-tra-skincare-moi-da-nhay-cam',
    title: '4 bước kiểm tra skincare mới trước khi đưa vào routine cho da nhạy cảm',
    category: 'Da nhạy cảm',
    date: '18 Tháng 09, 2026',
    readTime: '4 phút đọc',
    summary: 'Quy trình patch test khoa học giúp bạn chủ động nhận diện độ tương thích của mỹ phẩm mới, giảm thiểu tối đa rủi ro bùng phát kích ứng.',
    thumbnail: '/src/assets/images/botanical_texture_leaves_1790145845639.jpg',
    contentParagraphs: [
      'Đối với làn da dễ kích ứng, việc đổi một lọ serum hay kem dưỡng mới luôn đi kèm tâm lý lo lắng. Không có bất kỳ sản phẩm nào có thể cam kết 100% phù hợp với mọi cá nhân, bởi cơ địa da của mỗi người là duy nhất.',
      'Để hạn chế tình trạng breakout không mong muốn, bước đầu tiên luôn là đọc kỹ bảng thành phần (INCI). Hãy tìm kiếm các sản phẩm không chứa hương liệu nhân tạo nồng độ cao, cồn khô biến tính (Denatured Alcohol) và các chất tạo màu.',
      'Tiếp theo, hãy thực hiện bài kiểm tra phản ứng (Patch Test) trong vòng 24 - 48 giờ ở vùng da kín đáo như phía dưới quai hàm hoặc nếp gấp cánh tay trước khi thoa toàn mặt.',
      'Khi bắt đầu, chỉ dùng cách ngày (2 - 3 lần/tuần) trong 2 tuần đầu tiên để da có thời gian thích ứng với các hoạt chất chống oxy hóa mới.'
    ],
    keyTakeaways: [
      'Luôn đọc kỹ INCI thay vì chỉ tin vào lời quảng cáo ngoài bao bì.',
      'Patch test là bước bắt buộc cho mọi sản phẩm dưỡng da mới.',
      'Tần suất khởi đầu nên là 2-3 lần/tuần trước khi tăng lên dùng hàng ngày.'
    ]
  },
  {
    id: 'lam-the-nao-de-dua-san-pham-moi-vao-routine',
    title: 'Làm thế nào để đưa sản phẩm mới vào routine mà không gây quá tải cho da?',
    category: 'Routine',
    date: '12 Tháng 09, 2026',
    readTime: '5 phút đọc',
    summary: 'Nguyên tắc tối giản "One-In, One-Out" và cách lắng nghe phản ứng màng ẩm tự nhiên để da không bị "bội thực" dưỡng chất.',
    thumbnail: '/src/assets/images/skincare_routine_vietnamese_1790145859103.jpg',
    contentParagraphs: [
      'Gen Z thường tiếp cận rất nhiều xu hướng skincare trên mạng xã hội, dẫn đến thói quen thử cùng lúc nhiều hoạt chất nồng độ cao như AHA, BHA, Retinol và Vitamin C. Điều này dễ làm suy yếu hàng rào bảo vệ màng ẩm.',
      'Nguyên tắc vàng là: Chỉ thêm duy nhất một sản phẩm mới vào chu trình tại một thời điểm, và giữ nguyên các bước cơ bản (Làm sạch - Cấp ẩm - Chống nắng) trong ít nhất 2 đến 3 tuần.',
      'Nếu bạn thêm Vedera Vitamin C Serum, hãy ưu tiên dùng vào buổi sáng cùng kem chống nắng để phát huy hiệu quả hỗ trợ bảo vệ da trước gốc tự do, đồng thời tạm hoãn các hoạt chất peel da mạnh vào cùng buổi.'
    ],
    keyTakeaways: [
      'Chỉ bổ sung 1 sản phẩm mới mỗi 2-3 tuần.',
      'Không kết hợp dồn dập các hoạt chất acid mạnh cùng một buổi khi da chưa ổn định.',
      'Kem chống nắng là bước không thể tách rời khi dùng serum sáng da.'
    ]
  },
  {
    id: 'vitamin-c-va-nhung-hieu-lam-thuong-gap',
    title: 'Vitamin C có thực sự làm mỏng da? Những hiểu lầm thường gặp của người mới bắt đầu',
    category: 'Vitamin C',
    date: '05 Tháng 09, 2026',
    readTime: '6 phút đọc',
    summary: 'Giải mã bản chất của Vitamin C dạng dẫn xuất E-AA so với L-AA truyền thống, cùng góc nhìn khoa học về cơ chế bảo vệ da.',
    thumbnail: '/src/assets/images/product_serum_30ml_1790145833338.jpg',
    contentParagraphs: [
      'Nhiều bạn trẻ ngần ngại dùng Vitamin C vì sợ da bị bào mòn và bắt nắng dữ dội hơn. Trên thực tế, Vitamin C là chất chống oxy hóa tự nhiên giúp trung hòa các gốc tự do sinh ra từ tia tử ngoại và ô nhiễm môi trường.',
      'Hiểu lầm này xuất phát từ việc nhiều người dùng L-Ascorbic Acid nồng độ cao ở độ pH quá thấp (< 3.5), gây bong tróc nhẹ nếu da chưa từng làm quen.',
      'Vedera lựa chọn dẫn xuất 3-O-Ethyl Ascorbic Acid (E-AA) vì tính chất dịu nhẹ, hoạt động ổn định ở pH trung tính 5.5 - 6.0, không gây cảm giác châm chích dữ dội mà vẫn thẩm thấu hiệu quả.'
    ],
    keyTakeaways: [
      'Vitamin C không bào mòn da mà hỗ trợ tăng khả năng chống chịu oxy hóa.',
      'Dẫn xuất E-AA là lựa chọn thông minh cho da nhạy cảm mới bắt đầu.',
      'Bắt buộc dùng kèm kem chống nắng phổ rộng mỗi buổi sáng.'
    ]
  },
  {
    id: 'vi-sao-can-kiem-tra-nguon-goc-thanh-phan',
    title: 'Những thông tin cần kiểm tra trên bao bì mỹ phẩm trước khi bấm "Mua ngay"',
    category: 'Thành phần skincare',
    date: '28 Tháng 08, 2026',
    readTime: '4 phút đọc',
    summary: 'Cẩm nang cho người tiêu dùng thông thái: Cách tra cứu bảng INCI, hạn mở nắp (PAO) và tiêu chuẩn an toàn.',
    thumbnail: '/src/assets/images/hero_serum_vedera_1790145819228.jpg',
    contentParagraphs: [
      'Thay vì chỉ nhìn vào bao bì bắt mắt hoặc số lượng review trên livestream, người tiêu dùng thông minh luôn tìm kiếm sự minh bạch từ nhãn mác sản phẩm.',
      'Bảng INCI (International Nomenclature of Cosmetic Ingredients) liệt kê các thành phần theo thứ tự giảm dần về tỷ lệ. Những chất xuất hiện ở 5 vị trí đầu tiên đóng vai trò nền tảng cho kết cấu và hiệu quả của sản phẩm.',
      'Ngoài ra, hãy kiểm tra biểu tượng chiếc hũ mở nắp (PAO - Period After Opening), thông thường là 6M (6 tháng) hoặc 12M (12 tháng), cùng thông tin nhà sản xuất và số tiếp nhận công bố mỹ phẩm được cấp phép.'
    ],
    keyTakeaways: [
      'Tập thói quen đọc top 5 thành phần đầu tiên trong bảng INCI.',
      'Lưu ý hạn sử dụng sau khi mở nắp (PAO).',
      'Minh bạch thông tin là thước đo quan trọng nhất cho sự uy tín của thương hiệu.'
    ]
  },
  {
    id: 'skincare-thuan-chay-va-loi-song-xanh',
    title: 'Skincare thuần chay: Lựa chọn vì làn da hay trách nhiệm với môi trường?',
    category: 'Skincare thuần chay',
    date: '20 Tháng 08, 2026',
    readTime: '5 phút đọc',
    summary: 'Hiểu đúng về mỹ phẩm thuần chay (Vegan) và không thử nghiệm trên động vật (Cruelty-free) trong xu hướng tiêu dùng của Gen Z.',
    thumbnail: '/src/assets/images/botanical_texture_leaves_1790145845639.jpg',
    contentParagraphs: [
      'Mỹ phẩm thuần chay không đơn thuần là một trào lưu nhất thời, mà thể hiện quan điểm sống có trách nhiệm của thế hệ trẻ đối với hệ sinh thái tự nhiên.',
      'Thuần chay (Vegan) trong mỹ phẩm đồng nghĩa với việc hoàn toàn không sử dụng các chiết xuất từ động vật như mỡ lông cừu (Lanolin), nhớt ốc sên, hay sáp ong. Thay vào đó, các dưỡng chất được chắt lọc từ thực vật canh tác hữu cơ.',
      'Kết hợp cùng cam kết Cruelty-free, Vedera hướng đến việc tạo ra chu trình dưỡng da lành tính, tôn trọng quyền lợi của muôn loài và thiên nhiên.'
    ],
    keyTakeaways: [
      'Thuần chay là không sử dụng thành phần có nguồn gốc từ động vật.',
      'Cruelty-free là cam kết không tiến hành thử nghiệm trên động vật ở bất kỳ khâu nào.',
      'Lựa chọn thuần chay đồng hành cùng xu hướng sống xanh và phát triển bền vững.'
    ]
  }
];

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export const FAQS_DATA: FAQItem[] = [
  {
    id: 'faq-1',
    question: 'Serum Vitamin C Vedera phù hợp với những ai?',
    answer: 'Serum phù hợp với các bạn trẻ từ 18 tuổi trở lên, đặc biệt là sinh viên và người mới đi làm có làn da xỉn màu, vết thâm mụn nhẹ hoặc người có làn da nhạy cảm muốn làm quen với Vitamin C dịu nhẹ.',
    category: 'Sản phẩm'
  },
  {
    id: 'faq-2',
    question: 'Da nhạy cảm có nên dùng sản phẩm ngay trên toàn mặt không?',
    answer: 'Không nên. Chúng tôi luôn khuyến nghị bạn thực hiện patch test thử một lượng nhỏ ở vùng quai hàm trong 24-48 giờ trước. Chỉ khi da không xuất hiện dấu hiệu đỏ rát hay ngứa bất thường mới thoa dần lên mặt.',
    category: 'Sử dụng'
  },
  {
    id: 'faq-3',
    question: 'Serum được sử dụng ở bước nào trong routine hàng ngày?',
    answer: 'Serum Vedera được dùng sau bước Làm sạch (Tẩy trang, Sữa rửa mặt) và Cân bằng ẩm (Toner). Sau khi thoa serum và đợi 1-2 phút cho thấm, bạn tiếp tục thoa kem dưỡng ẩm và kem chống nắng (vào ban ngày).',
    category: 'Sử dụng'
  },
  {
    id: 'faq-4',
    question: 'Một ngày nên sử dụng bao nhiêu lần?',
    answer: 'Trong 2 tuần đầu tiên: Nên dùng 2 - 3 lần/tuần vào buổi sáng để theo dõi độ tương thích của da. Khi da đã quen: Có thể duy trì 1 lần/ngày vào mỗi buổi sáng kèm kem chống nắng đầy đủ.',
    category: 'Sử dụng'
  },
  {
    id: 'faq-5',
    question: 'Serum có cần bảo quản trong tủ lạnh không?',
    answer: 'Dẫn xuất 3-O-Ethyl Ascorbic Acid (E-AA) trong Vedera Serum có độ bền nhiệt và ánh sáng tốt hơn L-AA thông thường, nên bạn chỉ cần để nơi khô ráo, tránh nắng trực tiếp. Bạn có thể bảo quản ngăn mát tủ lạnh nếu muốn cảm giác mát lạnh sảng khoái khi thoa.',
    category: 'Bảo quản'
  },
  {
    id: 'faq-6',
    question: 'Nếu da có dấu hiệu bất thường (đỏ, ngứa, nổi mụn nước) thì phải làm gì?',
    answer: 'Hãy ngừng sử dụng sản phẩm ngay lập tức, rửa sạch mặt bằng nước muối sinh lý hoặc nước mát. Không gãi hay chà xát mạnh. Bạn có thể liên hệ đội ngũ tư vấn của Vedera để được hỗ trợ kiểm tra routine, hoặc tham vấn ý kiến bác sĩ da liễu nếu triệu chứng không thuyên giảm.',
    category: 'An toàn'
  },
  {
    id: 'faq-7',
    question: 'Vedera có những cam kết cụ thể nào về nguồn gốc sản phẩm?',
    answer: 'Vedera cam kết 100% công thức thuần chay, không cồn khô, không hương liệu nhân tạo tổng hợp, không thử nghiệm trên động vật và công bố minh bạch toàn bộ bảng INCI theo đúng quy chuẩn tiếp nhận của cơ quan chức năng.',
    category: 'Cam kết'
  }
];

export const VEDERA_CORE_VALUES = [
  {
    code: '01',
    title: 'Minh bạch thành phần',
    description: 'Mọi thành phần trong sản phẩm đều được công bố rõ ràng tên khoa học (INCI), nguồn gốc và vai trò cụ thể. Không ẩn giấu nồng độ độc hại dưới danh nghĩa "công thức bí truyền".'
  },
  {
    code: '02',
    title: 'Định hướng thuần chay',
    description: 'Từ chối mọi nguyên liệu có nguồn gốc từ động vật. Tôn trọng hệ sinh thái và lối sống xanh của thế hệ người tiêu dùng có ý thức.'
  },
  {
    code: '03',
    title: 'Không thử nghiệm động vật',
    description: 'Cam kết Cruelty-free trong toàn bộ chuỗi nghiên cứu và thử nghiệm an toàn, hướng đến nền công nghiệp mỹ phẩm nhân đạo.'
  },
  {
    code: '04',
    title: 'Dịu lành cho da nhạy cảm',
    description: 'Lựa chọn các dẫn xuất thế hệ mới, tối ưu độ pH sinh lý và bổ sung các chiết xuất thực vật làm dịu, hạn chế tối đa rủi ro kích ứng.'
  },
  {
    code: '05',
    title: 'Trách nhiệm & Có cơ sở',
    description: 'Nói không với các quảng cáo thần thánh hóa công dụng hoặc hứa hẹn phi thực tế. Tư vấn chăm sóc da dựa trên kiến thức da liễu cơ bản.'
  }
];

export const CUSTOMER_CONCERNS = [
  {
    title: 'Nguồn gốc minh bạch',
    subtitle: 'Kiểm chứng bảng thành phần INCI công khai 100%',
    desc: 'Khách hàng có thể tra cứu từng hoạt chất, hiểu rõ lý do vì sao thành phần đó có mặt trong chai serum.'
  },
  {
    title: 'Test trước khi dùng',
    subtitle: 'Quy trình hướng dẫn Patch test chi tiết tại nhà',
    desc: 'Cung cấp hướng dẫn rõ ràng giúp khách hàng thử phản ứng trước khi thoa lên mặt, giảm tâm lý sợ kích ứng.'
  },
  {
    title: 'Tư vấn theo cá nhân',
    subtitle: 'Đội ngũ hỗ trợ rà soát routine hiện tại',
    desc: 'Không ép mua hàng nếu routine hiện tại của bạn chưa phù hợp để bổ sung sản phẩm mới.'
  },
  {
    title: 'Cam kết chính sách',
    subtitle: 'Chính sách đổi trả minh bạch khi có phản ứng bất thường',
    desc: '[Điền chính sách đổi trả thực tế của thương hiệu] nhằm bảo đảm quyền lợi tối đa cho người dùng.'
  }
];
