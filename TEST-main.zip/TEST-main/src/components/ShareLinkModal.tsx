import React, { useState } from 'react';
import { X, Copy, Check, ExternalLink, Globe, Sparkles, Code, Share2 } from 'lucide-react';

interface ShareLinkModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTab: string;
  isDesignSpecActive: boolean;
}

export const ShareLinkModal: React.FC<ShareLinkModalProps> = ({
  isOpen,
  onClose,
  currentTab,
  isDesignSpecActive,
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  // Base domain or deployed URL
  const baseUrl = window.location.origin + window.location.pathname;

  // Construct links
  const links = [
    {
      key: 'current',
      title: 'Link trang bạn đang xem hiện tại',
      url: isDesignSpecActive
        ? `${baseUrl}#design-spec`
        : `${baseUrl}#${currentTab}`,
      desc: isDesignSpecActive
        ? 'Dẫn thẳng vào Hồ Sơ Thiết Kế & Wireframe 8 hạng mục.'
        : `Dẫn thẳng vào trang ${currentTab.toUpperCase()}.`,
    },
    {
      key: 'spec',
      title: 'Link riêng: Hồ Sơ Thiết Kế & Wireframe (Dành cho Giảng viên / Đồ án)',
      url: `${baseUrl}#design-spec`,
      desc: 'Mở trực tiếp tài liệu Sitemap, Wireframe chi tiết 12 sections, Content Copy & Design System.',
    },
    {
      key: 'home',
      title: 'Link riêng: Trang Chủ Vedera Skincare',
      url: `${baseUrl}#home`,
      desc: 'Giao diện thương hiệu hoàn chỉnh dành cho khách hàng.',
    },
    {
      key: 'product',
      title: 'Link riêng: Trang Chi Tiết Serum Vitamin C 30ml (PDP)',
      url: `${baseUrl}#product`,
      desc: 'Trang thông tin sản phẩm, tra cứu bảng thành phần INCI và đặt hàng.',
    },
  ];

  const handleCopy = (key: string, url: string) => {
    navigator.clipboard?.writeText(url);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2200);
  };

  const handleOpenNewTab = (url: string) => {
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-[#FAF8F5] rounded-3xl shadow-2xl border border-[#E8E4DF] overflow-hidden">
        {/* Header */}
        <div className="p-6 bg-white border-b border-[#E8E4DF] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#EDF3EE] text-[#1F3D2B] flex items-center justify-center">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-xl sm:text-2xl font-semibold text-[#1F3D2B]">
                Xuất Link Riêng & Chia Sẻ Website
              </h3>
              <p className="text-xs text-[#68776B]">
                Các đường dẫn độc lập để nộp bài tập, gửi khách hàng hoặc mở toàn màn hình
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#5F6D62] hover:text-[#1F3D2B] rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Quick Guide */}
          <div className="p-4 bg-[#EDF3EE] rounded-2xl border border-[#CBD5CD] text-xs text-[#1F3D2B] space-y-1.5">
            <p className="font-semibold flex items-center gap-1.5">
              <Globe className="w-4 h-4 text-[#1F3D2B]" />
              <span>Website đã có link online thực tế có thể truy cập từ mọi thiết bị!</span>
            </p>
            <p className="text-[#3E5544] leading-relaxed">
              Bạn có thể sao chép đường link bên dưới để gửi qua Zalo, Messenger, dán vào file Word báo cáo đồ án, hoặc bấm <strong>"Mở tab mới"</strong> để xem website toàn màn hình không có khung AI Studio.
            </p>
          </div>

          {/* Links List */}
          <div className="space-y-3.5">
            {links.map((item) => (
              <div
                key={item.key}
                className="bg-white p-4 rounded-2xl border border-[#E8E4DF] space-y-2.5 shadow-2xs hover:border-[#CBD5CD] transition-all"
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-xs text-[#1F3D2B]">{item.title}</span>
                  <span className="text-[11px] text-[#87A98D] font-mono">{item.desc}</span>
                </div>

                <div className="flex items-center gap-2 bg-[#FAF8F5] p-2 rounded-xl border border-[#E8E4DF]">
                  <input
                    type="text"
                    readOnly
                    value={item.url}
                    className="flex-1 bg-transparent text-xs font-mono text-[#444D46] outline-none select-all truncate"
                  />
                  <button
                    onClick={() => handleCopy(item.key, item.url)}
                    className="px-3 py-1.5 bg-[#1F3D2B] text-white text-xs font-semibold rounded-lg hover:bg-[#162E20] transition-colors flex items-center gap-1 cursor-pointer shrink-0"
                  >
                    {copiedKey === item.key ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Đã chép</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Sao chép</span>
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => handleOpenNewTab(item.url)}
                    className="p-1.5 text-[#5F6D62] hover:text-[#1F3D2B] hover:bg-[#EAE5DE] rounded-lg transition-colors cursor-pointer shrink-0"
                    title="Mở trong tab trình duyệt mới"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* 3 Methods to export / publish elsewhere */}
          <div className="pt-2 border-t border-[#E8E4DF] space-y-3">
            <h4 className="font-semibold text-xs uppercase tracking-wider text-[#1F3D2B] flex items-center gap-1.5">
              <Code className="w-4 h-4 text-[#87A98D]" />
              <span>3 Cách xuất ra link riêng / tên miền riêng:</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 bg-white rounded-xl border border-[#E8E4DF] space-y-1">
                <span className="font-semibold text-[#1F3D2B] block">1. Dùng link online có sẵn:</span>
                <p className="text-[#68776B] text-[11px] leading-relaxed">
                  Sao chép link ở trên và gửi ngay cho giảng viên hoặc đưa vào slide thuyết trình. Hoàn toàn miễn phí.
                </p>
              </div>

              <div className="p-3 bg-white rounded-xl border border-[#E8E4DF] space-y-1">
                <span className="font-semibold text-[#1F3D2B] block">2. Mở tab độc lập:</span>
                <p className="text-[#68776B] text-[11px] leading-relaxed">
                  Bấm biểu tượng mũi tên mở cửa sổ mới ở góc trên thanh công cụ AI Studio để xem ở chế độ full-browser.
                </p>
              </div>

              <div className="p-3 bg-white rounded-xl border border-[#E8E4DF] space-y-1">
                <span className="font-semibold text-[#1F3D2B] block">3. Đưa lên Vercel / Netlify:</span>
                <p className="text-[#68776B] text-[11px] leading-relaxed">
                  Tải source code về, đẩy lên GitHub rồi import vào Vercel (chỉ mất 2 phút) để gắn tên miền riêng .vn hoặc .com.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-white border-t border-[#E8E4DF] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#1F3D2B] text-white text-xs font-semibold rounded-xl hover:bg-[#162E20] transition-colors cursor-pointer"
          >
            Đã hiểu & Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
