import React from 'react';
import { ShieldCheck, HeartHandshake, Leaf, ArrowUpRight } from 'lucide-react';

interface FooterProps {
  onSelectTab: (tab: string) => void;
  onOpenConsultation: () => void;
  onToggleDesignSpec: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectTab,
  onOpenConsultation,
  onToggleDesignSpec,
}) => {
  return (
    <footer className="bg-[#19241C] text-[#DCE4DE] pt-16 pb-12 border-t border-[#29382E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top 3 Trust Badges (clean unboxed textual style) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pb-12 border-b border-[#2C3B31]">
          <div className="flex items-start gap-3.5">
            <div className="p-2.5 rounded-xl bg-[#233327] text-[#87A98D] shrink-0">
              <Leaf className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-medium text-white text-sm">Công Thức Thuần Chay 100%</h4>
              <p className="text-xs text-[#9EACA1] mt-1 leading-relaxed">
                Không chứa bất kỳ dẫn xuất nào từ động vật. Nguồn gốc thực vật hữu cơ lành tính.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5">
            <div className="p-2.5 rounded-xl bg-[#233327] text-[#87A98D] shrink-0">
              <HeartHandshake className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-medium text-white text-sm">Cruelty-Free (Không thử nghiệm động vật)</h4>
              <p className="text-xs text-[#9EACA1] mt-1 leading-relaxed">
                Cam kết nhân đạo trong toàn bộ quá trình nghiên cứu và bào chế sản phẩm.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5">
            <div className="p-2.5 rounded-xl bg-[#233327] text-[#87A98D] shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-medium text-white text-sm">Minh Bạch Bảng INCI Đầy Đủ</h4>
              <p className="text-xs text-[#9EACA1] mt-1 leading-relaxed">
                Công bố toàn bộ thành phần khoa học, tỷ lệ an toàn cho da nhạy cảm.
              </p>
            </div>
          </div>
        </div>

        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 py-12 border-b border-[#2C3B31]">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="space-y-1">
              <span className="font-serif text-3xl font-semibold tracking-wide text-white">
                VEDERA
              </span>
              <span className="block text-[11px] uppercase tracking-[0.2em] text-[#87A98D]">
                Clean Beauty & Vegan Skincare
              </span>
            </div>
            <p className="text-sm text-[#A9B7AC] leading-relaxed max-w-sm">
              Vedera Skincare ra đời với sứ mệnh mang đến giải pháp chăm sóc da minh bạch, lành tính và an toàn cho người trẻ Việt Nam, đặc biệt là làn da nhạy cảm dễ kích ứng.
            </p>
            <div className="pt-2 flex items-center gap-3 text-xs text-[#C5D3C8]">
              <span className="inline-block w-2 h-2 rounded-full bg-[#87A98D]"></span>
              <span>Định vị: Minh Bạch · Thuần Chay · Chăm Da Có Cơ Sở</span>
            </div>
          </div>

          {/* Column: Điều Hướng */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-[#87A98D]">
              Điều Hướng
            </h4>
            <ul className="space-y-2 text-sm text-[#BAC7BD]">
              <li>
                <button
                  onClick={() => onSelectTab('home')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Trang chủ
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('about')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Về Vedera
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('product')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Sản phẩm (Serum C)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('routine')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Hướng dẫn Patch test
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('blog')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Kiến thức Skincare
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('faq')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Câu hỏi thường gặp
                </button>
              </li>
            </ul>
          </div>

          {/* Column: Chính Sách */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-[#87A98D]">
              Chính Sách & Hỗ Trợ
            </h4>
            <ul className="space-y-2 text-sm text-[#BAC7BD]">
              <li className="hover:text-white transition-colors cursor-pointer">
                Chính sách bảo mật dữ liệu
              </li>
              <li className="hover:text-white transition-colors cursor-pointer">
                Chính sách mua hàng & Giao hàng
              </li>
              <li className="hover:text-white transition-colors cursor-pointer">
                Chính sách đổi trả khi kích ứng
              </li>
              <li className="hover:text-white transition-colors cursor-pointer">
                Điều khoản sử dụng website
              </li>
              <li>
                <button
                  onClick={onOpenConsultation}
                  className="text-[#87A98D] hover:underline font-medium flex items-center gap-1 cursor-pointer"
                >
                  <span>Nhận tư vấn routine</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </li>
              <li>
                <button
                  onClick={onToggleDesignSpec}
                  className="text-[#D3E0D6] hover:text-white flex items-center gap-1 cursor-pointer text-xs pt-1"
                >
                  <span>Hồ sơ thiết kế (Đồ án)</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-[#87A98D]" />
                </button>
              </li>
            </ul>
          </div>

          {/* Column: Liên Hệ */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-[#87A98D]">
              Kết Nối Với Vedera
            </h4>
            <div className="space-y-2 text-sm text-[#BAC7BD]">
              <p>
                <span className="text-xs text-[#87A98D] block">Email hỗ trợ:</span>
                hello@vederaskincare.vn
              </p>
              <p>
                <span className="text-xs text-[#87A98D] block">Hotline tư vấn:</span>
                1900 xxxx <span className="text-xs text-[#87A98D]">[Điền số hotline thực tế]</span>
              </p>
              <p>
                <span className="text-xs text-[#87A98D] block">Kênh mạng xã hội:</span>
                Facebook: <span className="text-xs text-[#87A98D]">[Điền Fanpage Vedera]</span>
                <br />
                TikTok: <span className="text-xs text-[#87A98D]">[Điền TikTok @vedera.vn]</span>
              </p>
              <p className="text-xs text-[#87A98D] pt-1">
                Địa chỉ: [Điền địa chỉ văn phòng/đơn vị đăng ký]
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar & Copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-[#8B9B8E] gap-4">
          <p>© 2026 Vedera Skincare. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span>Website phục vụ đồ án thiết kế thương hiệu mỹ phẩm</span>
            <span aria-hidden="true">·</span>
            <span>Không tự tạo review/số liệu giả</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
