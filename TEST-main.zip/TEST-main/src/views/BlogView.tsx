import React, { useState } from 'react';
import { Clock, ArrowRight, X, BookOpen, Share2, Sparkles } from 'lucide-react';
import { ARTICLES_DATA, ArticleItem } from '../data/vederaContent';

interface BlogViewProps {
  onOpenConsultation: () => void;
}

export const BlogView: React.FC<BlogViewProps> = ({ onOpenConsultation }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [readingArticle, setReadingArticle] = useState<ArticleItem | null>(null);

  const categories = [
    { id: 'all', label: 'Tất cả' },
    { id: 'Chăm sóc da', label: 'Chăm sóc da' },
    { id: 'Da nhạy cảm', label: 'Da nhạy cảm' },
    { id: 'Thành phần skincare', label: 'Thành phần skincare' },
    { id: 'Routine', label: 'Routine' },
    { id: 'Vitamin C', label: 'Vitamin C' },
    { id: 'Skincare thuần chay', label: 'Skincare thuần chay' },
  ];

  const filteredArticles =
    selectedCategory === 'all'
      ? ARTICLES_DATA
      : ARTICLES_DATA.filter((a) => a.category === selectedCategory);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
      {/* Header */}
      <div className="max-w-3xl mx-auto text-center space-y-4">
        <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
          Kho Tri Thức Chăm Da
        </span>
        <h1 className="font-serif text-4xl sm:text-5xl font-semibold text-[#1F3D2B]">
          Kiến thức skincare & Khoa học làn da
        </h1>
        <p className="text-sm sm:text-base text-[#526155] leading-relaxed">
          Đọc và hiểu bản chất của từng hoạt chất trước khi đưa vào chu trình. Chăm sóc da có cơ sở, không chạy theo trào lưu giật gân.
        </p>
      </div>

      {/* Categories Filter Tabs (Interactive Controls) */}
      <div className="flex flex-wrap items-center justify-center gap-1.5 p-1.5 bg-[#F0ECE4] rounded-2xl max-w-fit mx-auto border border-[#E2DDD3]">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-xl transition-all cursor-pointer ${
              selectedCategory === cat.id
                ? 'bg-[#1F3D2B] text-white shadow-xs'
                : 'text-[#4F5B52] hover:text-[#1F3D2B]'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Articles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredArticles.map((art) => (
          <article
            key={art.id}
            onClick={() => setReadingArticle(art)}
            className="bg-white rounded-2xl border border-[#E8E4DF] overflow-hidden group hover:border-[#CBD5CD] hover:shadow-xs transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="aspect-16/10 overflow-hidden bg-[#F0EBE1]">
                <img
                  src={art.thumbnail}
                  alt={art.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                />
              </div>

              <div className="p-6 space-y-3">
                <div className="flex items-center gap-2 text-xs text-[#87A98D] font-medium">
                  <span>{art.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{art.date}</span>
                  <span aria-hidden="true">·</span>
                  <span>{art.readTime}</span>
                </div>

                <h3 className="font-semibold text-lg text-[#1F3D2B] group-hover:text-[#162E20] leading-snug">
                  {art.title}
                </h3>

                <p className="text-xs sm:text-sm text-[#5F6D62] line-clamp-3 leading-relaxed">
                  {art.summary}
                </p>
              </div>
            </div>

            <div className="px-6 pb-6 pt-2 flex items-center justify-between text-xs font-semibold text-[#1F3D2B] border-t border-[#FAF8F5]">
              <span>Đọc toàn bộ bài viết</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </article>
        ))}
      </div>

      {/* Article Full Reader Modal */}
      {readingArticle && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-2xl bg-[#FAF8F5] rounded-3xl shadow-2xl border border-[#E8E4DF] overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Top */}
            <div className="p-5 bg-white border-b border-[#E8E4DF] flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs text-[#87A98D] font-medium">
                <span>{readingArticle.category}</span>
                <span aria-hidden="true">·</span>
                <span>{readingArticle.readTime}</span>
              </div>
              <button
                onClick={() => setReadingArticle(null)}
                className="p-1 text-[#5F6D62] hover:text-[#1F3D2B] rounded-lg transition-colors cursor-pointer"
                aria-label="Đóng bài viết"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
              <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-[#1F3D2B] leading-tight">
                {readingArticle.title}
              </h2>

              <div className="rounded-2xl overflow-hidden aspect-16/9 bg-[#F0EBE1]">
                <img
                  src={readingArticle.thumbnail}
                  alt={readingArticle.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Content Paragraphs */}
              <div className="space-y-4 text-sm text-[#444D46] leading-relaxed">
                {readingArticle.contentParagraphs.map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
              </div>

              {/* Key Takeaways */}
              <div className="p-5 bg-[#EDF3EE] rounded-2xl space-y-2 border border-[#CBD5CD]">
                <h4 className="font-semibold text-xs uppercase tracking-wider text-[#1F3D2B]">
                  Điểm cốt lõi cần nhớ:
                </h4>
                <ul className="space-y-1.5 text-xs text-[#2A4633]">
                  {readingArticle.keyTakeaways.map((takeaway, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span>•</span>
                      <span>{takeaway}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Call to action inside blog */}
              <div className="p-4 bg-white rounded-xl border border-[#E8E4DF] flex items-center justify-between text-xs">
                <div>
                  <span className="font-semibold text-[#1F3D2B] block">Bạn cần giải đáp về routine?</span>
                  <span className="text-[#68776B]">Tư vấn cá nhân hóa miễn phí 100% cùng Vedera.</span>
                </div>
                <button
                  onClick={() => {
                    setReadingArticle(null);
                    onOpenConsultation();
                  }}
                  className="px-4 py-2 bg-[#1F3D2B] text-white font-medium rounded-lg hover:bg-[#162E20] transition-colors cursor-pointer"
                >
                  Tư vấn ngay
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
