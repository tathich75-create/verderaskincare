/**
 * HỒ SƠ THIẾT KẾ WEBSITE VEDERA SKINCARE
 * Phục vụ đồ án / bài tập đại học & triển khai thực tế
 * Đầy đủ 8 hạng mục: Sitemap, Wireframe, Content Copy, CTA Matrix, UX Flow, Design System, Responsive, Technical Recommendations.
 */

export interface SectionSpec {
  name: string;
  goal: string;
  contentCopy: string;
  ctaText: string;
  imageSuggestion: string;
  uxUiNotes: string;
}

export const WIREFRAME_SECTIONS_SPEC: SectionSpec[] = [
  {
    name: 'SECTION 01 – HERO (Trang chủ)',
    goal: 'Trong 3 giây đầu tiên giúp khách hàng (Gen Z, da nhạy cảm) nhận diện ngay Vedera là thương hiệu skincare thuần chay, minh bạch và sản phẩm cốt lõi là Serum Vitamin C.',
    contentCopy: `Headline: "Chăm da lành tính, chọn skincare minh bạch."
Subheadline: "Vedera Skincare mang đến giải pháp chăm sóc da thuần chay, hướng đến sự minh bạch trong thành phần và trải nghiệm dịu nhẹ cho làn da."
Trust Markers: Thuần chay (Vegan) · Không thử nghiệm động vật (Cruelty-Free) · Dịu lành cho da nhạy cảm.`,
    ctaText: 'CTA chính: "Khám phá sản phẩm" | CTA phụ: "Tư vấn chăm sóc da"',
    imageSuggestion: 'Ảnh chai Serum Vitamin C 30ml đặt trên bệ đá travertine tự nhiên, ánh sáng ban mai nhẹ nhàng, bóng lá cây xanh nhẹ, phong cách clean beauty tối giản, không tạo cảm giác phòng thí nghiệm khô khan hay quảng cáo thuốc.',
    uxUiNotes: 'Áp dụng bố cục 1440px desktop baseline, split layout 50:50. Bên trái là Typography phân cấp rõ ràng (h1 serif 48px, text-wrap balance), bên phải là visual chất lượng cao. Nút CTA dạng pill hoặc bo góc 8px êm dịu, không pop-up gây giật mình.'
  },
  {
    name: 'SECTION 02 – GIỚI THIỆU NHANH VỀ VEDERA',
    goal: 'Định vị giá trị cốt lõi của thương hiệu một cách khiêm tốn, trung thực, không dùng mỹ từ phóng đại như "số 1", "hiệu quả thần tốc".',
    contentCopy: `Tiêu đề: "Vedera bắt đầu từ một lựa chọn đơn giản"
Nội dung: "Chúng tôi tin rằng chăm sóc da không nên là chuỗi ngày lo âu khi thử nghiệm mỹ phẩm mới. Vedera ra đời để mang đến chu trình skincare thuần chay, có nguồn gốc thực vật hữu cơ, tuyệt đối không thử nghiệm trên động vật và minh bạch 100% bảng thành phần. Mỗi giọt tinh chất là sự tôn trọng đối với màng ẩm sinh lý của làn da bạn."`,
    ctaText: 'CTA liên kết: "Tìm hiểu về Vedera →"',
    imageSuggestion: 'Texture giọt serum trong suốt phản chiếu ánh sáng tự nhiên và nhành thảo mộc tươi mát.',
    uxUiNotes: 'Sử dụng background nền kem nhạt (#FAF8F5), không lồng khung hộp trong hộp. Khoảng trắng thoáng đãng (padding y-16 đến y-20), typography cân đối 65ch.'
  },
  {
    name: 'SECTION 03 – NỖI ĐAU KHÁCH HÀNG (Problem Identification)',
    goal: 'Tạo sự đồng cảm sâu sắc với tâm lý bất an của Gen Z khi mua skincare: sợ kích ứng, sợ quảng cáo lố, khó kiểm chứng thành phần.',
    contentCopy: `Tiêu đề: "Skincare mới – điều gì khiến bạn lo lắng?"
Mô tả: "Chúng tôi lắng nghe những băn khoăn rất thật của bạn trước khi quyết định bổ sung một sản phẩm vào routine:"
4 Vấn đề chính:
1. Không biết sản phẩm có thực sự phù hợp với loại da hay tình trạng hiện tại của mình.
2. Lo ngại nguy cơ kích ứng, nổi mẩn đỏ hay bùng mụn khi thêm hoạt chất mới.
3. Khó kiểm tra nguồn gốc xuất xứ và ý nghĩa thực sự của các chất trong bảng thành phần.
4. Bị choáng ngợp bởi hàng loạt review quảng cáo nhưng thiếu căn cứ khoa học kiểm chứng.`,
    ctaText: 'Không ép CTA mua hàng, dẫn dắt tự nhiên sang giải pháp.',
    imageSuggestion: 'Icon đường nét thanh mảnh tối giản mô tả làn da, kính lúp kiểm chứng, biểu đồ minh bạch.',
    uxUiNotes: 'Grid 4 cột trên Desktop (2 cột trên Tablet, 1 cột trên Mobile). Thẻ có nền trắng phẳng (#FFFFFF) với viền hairline 1px (#E8E4DF), không đổ bóng gắt hay dùng hiệu ứng giật gân.'
  },
  {
    name: 'SECTION 04 – GIẢI PHÁP CỦA VEDERA',
    goal: 'Đưa ra câu trả lời trực tiếp cho 4 nỗi đau trên bằng 4 cam kết nền tảng, tôn trọng sự an toàn của khách hàng.',
    contentCopy: `Tiêu đề: "Một lựa chọn rõ ràng hơn cho routine của bạn"
4 Điểm cốt lõi:
01. Skincare thuần chay: 100% không sử dụng dẫn xuất động vật, lựa chọn dưỡng chất từ hệ thực vật lành tính.
02. Thành phần có nguồn gốc hữu cơ: Minh bạch xuất xứ chiết xuất (như rau má hữu cơ), chỉ đưa ra tuyên bố có cơ sở thực tế.
03. Không thử nghiệm trên động vật: Cam kết Cruelty-free trong toàn bộ quy trình phát triển sản phẩm.
04. Hướng đến làn da nhạy cảm: Tối ưu pH 5.5-6.0, dùng dẫn xuất Vitamin C thế hệ mới (E-AA) giảm thiểu châm chích. Không cam kết tuyệt đối 100% không kích ứng vì tôn trọng cơ địa riêng biệt của mỗi người.`,
    ctaText: 'CTA: "Xem chi tiết sản phẩm →"',
    imageSuggestion: 'Ảnh chụp cành rau má tươi và nguyên liệu thực vật hữu cơ tự nhiên trên nền đá mờ sương.',
    uxUiNotes: 'Đánh số thứ tự tự nhiên (01, 02, 03, 04) bằng font serif trang nhã, không dùng ký hiệu code mechanical như // hay >_.'
  },
  {
    name: 'SECTION 05 – SẢN PHẨM NỔI BẬT (Featured PDP Preview)',
    goal: 'Trình bày sản phẩm trọng tâm Vedera Vitamin C Serum 30ml với đầy đủ thông tin kỹ thuật, không nói quá công dụng.',
    contentCopy: `Tên: VEDERA VITAMIN C GENTLE BRIGHTENING SERUM
Dung tích: 30ml (1.01 fl. oz.)
Định hướng sử dụng: Hỗ trợ làm đều màu da, chống oxy hóa nhẹ nhàng trước tác nhân khói bụi và ánh nắng, củng cố màng ẩm.
Thành phần nổi bật: 3-O-Ethyl Ascorbic Acid (Dẫn xuất C ổn định), Chiết xuất Rau má Hữu cơ, Sodium Hyaluronate đa tầng, D-Panthenol B5.
Đối tượng phù hợp: Da xỉn màu, có vết thâm sau mụn, da nhạy cảm muốn làm quen với Vitamin C.
Lưu ý: Luôn patch test trước khi dùng; bắt buộc dùng kem chống nắng vào ban ngày.`,
    ctaText: 'CTA chính: "Xem chi tiết sản phẩm" | "Nhận tư vấn routine"',
    imageSuggestion: 'Ảnh chai serum 30ml với dropper nhỏ giọt tinh chất trong suốt, ánh sáng tự nhiên.',
    uxUiNotes: 'Card sản phẩm chuẩn e-commerce cao cấp: tỷ lệ ảnh 1:1 rõ nét, hiển thị giá rõ ràng, có nhãn dung tích, liên kết trực tiếp vào trang PDP chi tiết.'
  },
  {
    name: 'SECTION 06 – HOW IT WORKS (Quy trình 3 bước & Thử phản ứng)',
    goal: 'Hướng dẫn người dùng tiếp cận skincare an toàn, nâng cao nhận thức về Patch Test trước khi dùng.',
    contentCopy: `Tiêu đề: "Bắt đầu routine cùng Vedera chỉ với 3 bước"
Bước 1: Kiểm tra sản phẩm – Đọc kỹ bảng thành phần INCI và hạn sử dụng sau mở nắp (PAO).
Bước 2: Test trước khi dùng (Patch Test) – Thử một lượng nhỏ tại vùng quai hàm trong 24-48 giờ để theo dõi phản ứng màng ẩm.
Bước 3: Đưa vào routine – Sử dụng cách ngày 2-3 lần/tuần trong 2 tuần đầu; luôn kết hợp kem dưỡng ẩm và kem chống nắng.
LƯU Ý KHOA HỌC: Không có sản phẩm skincare nào có thể đảm bảo phù hợp 100% với mọi làn da. Hãy ngừng sử dụng nếu xuất hiện phản ứng bất thường và liên hệ tư vấn hoặc tham khảo chuyên gia khi cần.`,
    ctaText: 'CTA: "Xem cẩm nang Patch Test chi tiết"',
    imageSuggestion: 'Hình ảnh hướng dẫn đồ họa trực quan 3 bước và vị trí quai hàm để test mỹ phẩm.',
    uxUiNotes: 'Hộp cảnh báo khoa học viền nét mảnh nhã nhặn, màu nền sage green dịu mắt (#EDF3EE), không dùng màu đỏ cảnh báo gây hoảng loạn.'
  },
  {
    name: 'SECTION 07 – SOCIAL PROOF & ĐIỀU KHÁCH HÀNG QUAN TÂM',
    goal: 'Tạo dựng niềm tin chân thực, TUÂN THỦ NGHIÊM NGẶT nguyên tắc không làm giả số liệu, không bịa đặt review hay chứng chỉ.',
    contentCopy: `Tiêu đề: "Điều khách hàng quan tâm khi lựa chọn Vedera"
Mô tả: "Thay vì đưa ra các con số quảng cáo phóng đại, Vedera minh bạch các tiêu chuẩn kiểm soát chất lượng mà người tiêu dùng thông thái đặt ra:"
- Minh bạch 100% bảng thành phần INCI theo quy định tiếp nhận mỹ phẩm.
- Quy trình hướng dẫn Patch test chi tiết cho từng cá nhân trước khi mua.
- Cam kết chính sách hỗ trợ và lắng nghe phản hồi trải nghiệm thực tế.
- [Khu vực dành cho Feedback & Đánh giá thực tế từ người dùng thử nghiệm lâm sàng].`,
    ctaText: 'CTA: "Đọc thêm về tiêu chuẩn an toàn"',
    imageSuggestion: 'Ảnh tư liệu thực tế quá trình nghiên cứu công thức hoặc chân dung người dùng thật với làn da tự nhiên.',
    uxUiNotes: 'Tuyệt đối không đưa số liệu ảo "10.000 khách hàng", "4.9/5", "98% hiệu quả sau 3 ngày". Giữ giao diện trung thực, thanh lịch.'
  },
  {
    name: 'SECTION 08 – KIẾN THỨC SKINCARE (Content Hub)',
    goal: 'Giáo dục khách hàng, tăng thời gian on-site, xây dựng vị thế chuyên môn và hỗ trợ phễu SEO bền vững.',
    contentCopy: `Tiêu đề: "Hiểu da trước khi chọn sản phẩm"
5 Bài viết đề xuất:
1. 4 bước kiểm tra skincare mới trước khi đưa vào routine cho da nhạy cảm.
2. Làm thế nào để đưa sản phẩm mới vào routine mà không gây quá tải cho da?
3. Vitamin C có thực sự làm mỏng da? Những hiểu lầm thường gặp của người mới bắt đầu.
4. Những thông tin cần kiểm tra trên bao bì mỹ phẩm trước khi bấm "Mua ngay".
5. Skincare thuần chay: Lựa chọn vì làn da hay trách nhiệm với môi trường?`,
    ctaText: 'CTA: "Xem tất cả bài viết"',
    imageSuggestion: 'Ảnh bìa bài viết phong cách editorial, lá cây, quy trình chăm sóc da mộc mạc.',
    uxUiNotes: 'Dạng lưới 3 cột hiển thị tiêu đề, thời gian đọc (ví dụ: 4 phút đọc), phân loại danh mục unboxed metadata với ký tự phân tách "·".'
  },
  {
    name: 'SECTION 09 – FAQ (Câu hỏi thường gặp)',
    goal: 'Giải tỏa ngay lập tức các thắc mắc cốt tử trong tâm trí khách hàng trước khi ra quyết định.',
    contentCopy: `Bao gồm 7 câu hỏi chính xác:
- Serum Vitamin C phù hợp với ai?
- Da nhạy cảm có nên thử sản phẩm mới ngay không?
- Có cần test trước khi sử dụng không?
- Serum được sử dụng ở bước nào trong routine?
- Một ngày sử dụng bao nhiêu lần?
- Nếu da có dấu hiệu bất thường thì phải làm gì?
- Vedera có những cam kết gì về sản phẩm?`,
    ctaText: 'CTA mở rộng từng câu trả lời (Accordion).',
    imageSuggestion: 'Đồ họa thanh accordion tối giản, icon dấu cộng/trừ êm dịu.',
    uxUiNotes: 'Tương tác mượt mà dưới 200ms, nội dung câu trả lời súc tích, trung thực, không cam kết y khoa.'
  },
  {
    name: 'SECTION 10 – LEAD FORM / ĐĂNG KÝ TƯ VẤN ROUTINE',
    goal: 'Thu thập thông tin khách hàng tiềm năng cần tư vấn cá nhân hóa, giảm rào cản e ngại mua nhầm sản phẩm.',
    contentCopy: `Tiêu đề: "Chưa biết sản phẩm nào phù hợp với routine của bạn?"
Subheadline: "Để lại một vài thông tin để Vedera hỗ trợ bạn tìm hiểu sản phẩm phù hợp hơn."
Các trường nhập:
- Họ và tên
- Email
- Số điện thoại
- Tình trạng da (Da khô / Da dầu thiếu ẩm / Da hỗn hợp / Da nhạy cảm / Đang có mụn)
- Mục tiêu chăm sóc da (Làm sáng da / Làm mờ thâm / Cải thiện màng ẩm / Dưỡng sáng dịu nhẹ)
- Sản phẩm đang sử dụng hiện tại
- Nội dung bạn cần Vedera tư vấn chi tiết
Thông báo sau khi gửi: "Vedera đã nhận được thông tin. Cảm ơn bạn đã quan tâm đến Vedera Skincare. Đội ngũ chuyên viên sẽ liên hệ lại với bạn sớm nhất."`,
    ctaText: 'Nút gửi: "Đăng ký tư vấn"',
    imageSuggestion: 'Không cần ảnh phức tạp, tập trung vào form tinh gọn, rõ ràng.',
    uxUiNotes: 'Input có nhãn rõ ràng, focus ring tinh tế màu xanh lá thẫm (#2C4A34). Phản hồi trạng thái gửi tức thì (Inline feedback) không chuyển trang gây mất dấu.'
  },
  {
    name: 'SECTION 11 – CTA CUỐI TRANG (Final Pre-Sell Anchor)',
    goal: 'Lời kêu gọi hành động cuối cùng dựa trên sự thấu hiểu và tôn trọng làn da, không dùng chiêu trò FOMO ép mua.',
    contentCopy: `Headline: "Hiểu làn da. Chọn skincare có cơ sở."
Subheadline: "Bắt đầu hành trình chăm sóc da dịu lành cùng công thức thuần chay và bảng thành phần minh bạch từ Vedera."`,
    ctaText: 'CTA chính: "Khám phá Vedera" | CTA phụ: "Nhận tư vấn"',
    imageSuggestion: 'Background màu kem ấm (#F4EFEA) với đường cong uốn lượn nhẹ nhàng lấy cảm hứng từ giọt serum.',
    uxUiNotes: 'Nói KHÔNG với các từ ngữ giục ép: "Mua ngay kẻo hết", "Không mua sẽ tiếc", "Cam kết hiệu quả 100%".'
  },
  {
    name: 'SECTION 12 – FOOTER CHUẨN MỰC',
    goal: 'Cung cấp đầy đủ thông tin pháp lý, thương hiệu, điều hướng và kênh kết nối theo đúng tiêu chuẩn TMĐT.',
    contentCopy: `Thương hiệu: Vedera Skincare - Chăm sóc da thuần chay, nguồn gốc hữu cơ và minh bạch thông tin.
Điều hướng: Trang chủ · Về Vedera · Sản phẩm · Blog kiến thức · FAQ · Liên hệ
Chính sách: Chính sách bảo mật · Chính sách mua hàng · Chính sách đổi trả · Điều khoản sử dụng
Liên hệ: Email: hello@vederaskincare.vn · Hotline: 1900 xxxx [Placeholder] · Fanpage Facebook · Kênh TikTok · Địa chỉ: [Điền địa chỉ văn phòng thực tế]
Bản quyền: © 2026 Vedera Skincare. All rights reserved.`,
    ctaText: 'Liên kết văn bản trực tiếp.',
    imageSuggestion: 'Logo chữ Vedera tinh tế, các icon mạng xã hội tối giản.',
    uxUiNotes: 'Bố cục 4 cột trên desktop, 1 cột accordion trên mobile. Màu nền than đậm (#1E2621) hoặc xanh rêu sẫm nhạt sang trọng.'
  }
];

export const DESIGN_SYSTEM_SPEC = {
  colors: [
    { name: 'Forest Green (Chính/Nhận diện)', hex: '#1F3D2B', purpose: 'Màu nhận diện thương hiệu, nút CTA chính, tiêu đề quan trọng, tạo cảm giác thiên nhiên và đáng tin cậy.' },
    { name: 'Sage Green (Màu phụ/Làm dịu)', hex: '#87A98D', purpose: 'Màu nhấn dịu mát cho các huy hiệu phân loại, icon thiên nhiên, thanh tiến trình.' },
    { name: 'Soft Cream Linen (Nền chính)', hex: '#FAF8F5', purpose: 'Nền tổng thể toàn trang (60% canvas), ấm áp, dịu mắt, gợi nhắc mỹ phẩm sạch tự nhiên.' },
    { name: 'Travertine Neutral (Thẻ & Khung)', hex: '#F0EBE1', purpose: 'Bề mặt thẻ nổi, viền ngăn cách tinh tế, nền form nhập liệu.' },
    { name: 'Deep Botanical Charcoal (Chữ chính)', hex: '#2C332D', purpose: 'Màu chữ chính cho toàn bộ đoạn văn, đảm bảo độ tương phản chuẩn WCAG AA.' },
    { name: 'Muted Earth Olive (Chữ phụ & Meta)', hex: '#68776B', purpose: 'Màu chữ cho thời gian đọc, ngày tháng, danh mục, chú thích.' }
  ],
  typography: {
    displayFont: 'Cormorant Garamond (Serif tinh tế, thanh lịch, chuẩn clean beauty)',
    bodyFont: 'Plus Jakarta Sans (Sans-serif hiện đại, độ dễ đọc cao trên mọi màn hình Gen Z)',
    scale: [
      { level: 'Hero Display H1', size: '40px – 56px', weight: 'SemiBold 600', lineHeight: '1.15' },
      { level: 'Section Title H2', size: '32px – 40px', weight: 'Medium 500', lineHeight: '1.25' },
      { level: 'Card Title H3', size: '20px – 24px', weight: 'SemiBold 600', lineHeight: '1.3' },
      { level: 'Body Large', size: '16px – 18px', weight: 'Regular 400', lineHeight: '1.6' },
      { level: 'Body Regular', size: '15px – 16px', weight: 'Regular 400', lineHeight: '1.55' },
      { level: 'Unboxed Meta', size: '12px – 13px', weight: 'Medium 500', lineHeight: '1.4' }
    ]
  },
  buttons: [
    {
      type: 'Primary Button',
      style: 'Nền Forest Green (#1F3D2B), chữ trắng, bo góc 9999px (pill mượt) hoặc rounded-xl, padding px-6 py-3.5, hover đổi sang #162E20 kèm bóng đổ nhẹ êm ái.'
    },
    {
      type: 'Secondary Button',
      style: 'Nền trong suốt, viền 1.5px Forest Green (#1F3D2B), chữ Forest Green, hover sang nền xanh nhạt pha sương (#EDF3EE).'
    },
    {
      type: 'Text Link CTA',
      style: 'Chữ Forest Green gạch chân hairline, chuyển động dịch chuyển nhẹ mũi tên (translate-x-1) khi rê chuột.'
    }
  ],
  cards: 'Bề mặt phẳng 1 level elevation, viền hairline 1px solid rgba(44, 51, 45, 0.08), bo góc rounded-2xl (16px), padding tối thiểu 24px, không đổ bóng gắt 3D.',
  spacing: 'Desktop baseline 1440px, container tối đa 1240px, padding màn hình px-6 đến px-12, khoảng cách section py-16 đến py-24.'
};

export const UX_FLOW_SPEC = {
  title: 'HÀNH TRÌNH KHÁCH HÀNG (CUSTOMER JOURNEY & CONVERSION FUNNEL)',
  steps: [
    {
      stage: '1. Tiếp cận (Awareness)',
      channel: 'Facebook Post / Video TikTok (Nội dung giáo dục: "Vì sao Vitamin C thường gây châm chích và cách chọn dẫn xuất dịu nhẹ")',
      action: 'Người dùng quan tâm bấm vào liên kết trong bài viết / bio.'
    },
    {
      stage: '2. Truy cập Website (Consideration)',
      channel: 'Trang chủ Vedera / Trang chi tiết Serum Vitamin C',
      action: 'Đọc Headline "Chăm da lành tính, chọn skincare minh bạch" → Nhận diện ngay định vị thuần chay và nguồn gốc hữu cơ.'
    },
    {
      stage: '3. Đồng cảm & Thẩm định (Evaluation)',
      channel: 'Section Nỗi đau khách hàng & Bảng thành phần INCI minh bạch',
      action: 'Nhận ra giải pháp Vedera đúng với lo lắng của mình: không cồn, không hương liệu, dẫn xuất E-AA ổn định.'
    },
    {
      stage: '4. Tìm hiểu kỹ thuật (Education & Patch Test)',
      channel: 'Section How it works & Bài viết Blog',
      action: 'Khách hàng an tâm hơn khi thấy hướng dẫn test 24-48h và không có lời hứa hẹn "trắng cấp tốc" giả tạo.'
    },
    {
      stage: '5. Chuyển đổi (Conversion)',
      channel: 'Form Đăng ký tư vấn Routine HOẶC Nút điều hướng Mua hàng Shopee/TikTok Shop/Đặt hàng trực tiếp',
      action: 'Điền form thông tin da cá nhân để được tư vấn, hoặc chọn mua sản phẩm với đầy đủ chính sách minh bạch.'
    },
    {
      stage: '6. Chăm sóc sau mua (Retention & Advocacy)',
      channel: 'Email / Tin nhắn Zalo xác nhận kèm Thư cảm ơn',
      action: 'Gửi thiệp hướng dẫn Patch Test và lịch trình 14 ngày làm quen da, hỗ trợ theo dõi phản ứng và khảo sát hài lòng sau 3 tuần.'
    }
  ]
};

export const TECHNICAL_RECOMMENDATIONS = [
  {
    platform: 'React + Tailwind CSS / Vite (Khuyến nghị số 1 cho Đồ án & Demo)',
    suitability: 'Hoàn hảo nhất cho thuyết trình bài tập lớn, bảo vệ đồ án UI/UX',
    pros: 'Tùy biến 100% giao diện, tích hợp sẵn logic kiểm tra dị ứng, form tư vấn tương tác trực tiếp, chạy mượt mà không phụ thuộc hosting trả phí, chứng minh năng lực kỹ thuật và thiết kế trước giảng viên.',
    cons: 'Cần hiểu cơ bản về cấu trúc component web.',
    note: 'Đã được xây dựng hoàn thiện ngay trong applet này!'
  },
  {
    platform: 'Framer / Webflow (Khuyến nghị số 2 cho No-Code cao cấp)',
    suitability: 'Thích hợp cho Designer muốn dựng Landing Page mượt mà trực quan',
    pros: 'Hỗ trợ animation mượt, typography tinh tế, responsive tốt, dễ kéo thả.',
    cons: 'Bản miễn phí bị gắn watermark/badge, giới hạn trang và chức năng form nâng cao.'
  },
  {
    platform: 'WordPress + Elementor / WooCommerce',
    suitability: 'Phù hợp khi muốn vận hành cửa hàng TMĐT thực tế lâu dài',
    pros: 'Đầy đủ hệ sinh thái giỏ hàng, thanh toán ngân hàng Việt Nam (VNPay, MoMo), blog chuẩn SEO.',
    cons: 'Cần mua tên miền và hosting riêng, tốc độ tải có thể bị nặng nếu cài nhiều plugin.'
  },
  {
    platform: 'Google Sites / Wix',
    suitability: 'Dành cho bài tập nhanh cấp tốc',
    pros: 'Miễn phí, cực kỳ dễ dựng trong 1-2 giờ.',
    cons: 'Giao diện thô sơ, thiếu tính thẩm mỹ của ngành Clean Beauty, khó gây ấn tượng với giảng viên khó tính.'
  }
];
