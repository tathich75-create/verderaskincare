import React, { useState } from 'react';
import { ChevronDown, ChevronUp, HelpCircle, Sparkles, AlertTriangle } from 'lucide-react';
import { FAQS_DATA } from '../data/vederaContent';

interface FaqViewProps {
  onOpenConsultation: () => void;
}

export const FaqView: React.FC<FaqViewProps> = ({ onOpenConsultation }) => {
  const [openIds, setOpenIds] = useState<string[]>(['faq-1', 'faq-2']);

  const toggleFaq = (id: string) => {
    if (openIds.includes(id)) {
      setOpenIds(openIds.filter((item) => item !== id));
    } else {
      setOpenIds([...openIds, id]);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
      {/* Header */}
      <div className="text-center space-y-4">
        <span className="text-xs uppercase tracking-wider font-semibold text-[#87A98D]">
          Giải Đáp Minh Bạch
        </span>
        <h1 className="font-serif text-4xl sm:text-5xl font-semibold text-[#1F3D2B]">
          Câu hỏi thường gặp (FAQ)
        </h1>
        <p className="text-sm sm:text-base text-[#526155] leading-relaxed max-w-xl mx-auto">
          Mọi câu trả lời đều được xây dựng trên cơ sở khoa học da liễu cơ bản, không đưa ra cam kết y khoa hoặc kết quả tuyệt đối.
        </p>
      </div>

      {/* Accordion list */}
      <div className="space-y-3">
        {FAQS_DATA.map((faq) => {
          const isOpen = openIds.includes(faq.id);
          return (
            <div
              key={faq.id}
              className="bg-white rounded-2xl border border-[#E8E4DF] overflow-hidden transition-all shadow-2xs"
            >
              <button
                onClick={() => toggleFaq(faq.id)}
                className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-[#FAF8F5] transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono text-[#87A98D] uppercase">
                    {faq.category}
                  </span>
                  <span className="font-semibold text-sm sm:text-base text-[#1F3D2B]">
                    {faq.question}
                  </span>
                </div>
                <span className="text-[#87A98D] shrink-0">
                  {isOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </span>
              </button>
              {isOpen && (
                <div className="px-5 pb-5 text-xs sm:text-sm text-[#444D46] leading-relaxed border-t border-[#F2EDE6] pt-3 bg-[#FAF8F5]/40">
                  {faq.answer}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Reassurance Banner */}
      <div className="p-6 bg-[#EDF3EE] rounded-3xl border border-[#CBD5CD] text-center space-y-3">
        <h3 className="font-serif text-xl font-semibold text-[#1F3D2B]">
          Bạn có câu hỏi riêng cho tình trạng da của mình?
        </h3>
        <p className="text-xs sm:text-sm text-[#4E6654] max-w-md mx-auto leading-relaxed">
          Đội ngũ chuyên viên tư vấn của Vedera luôn sẵn sàng rà soát routine hiện tại cùng bạn hoàn toàn miễn phí.
        </p>
        <button
          onClick={onOpenConsultation}
          className="px-6 py-2.5 bg-[#1F3D2B] text-white text-xs font-semibold rounded-full hover:bg-[#162E20] transition-colors cursor-pointer"
        >
          Nhận tư vấn trực tiếp 1-1
        </button>
      </div>
    </div>
  );
};
